import React, { useState, useEffect } from 'react';
import { 
  Award, MapPin, Phone, Mail, Globe, Facebook, Instagram, Linkedin,
  BookOpen, Calendar, Bell, BarChart3, ChevronLeft, ChevronRight,
  Star, Quote, Menu, X, CheckCircle, Building, Target
} from 'lucide-react';

export default function LandingPage() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [currentSlide, setCurrentSlide] = useState(0);
  const [isVisible, setIsVisible] = useState(false);
  const [isNavbarVisible, setIsNavbarVisible] = useState(true);
  const [lastScrollY, setLastScrollY] = useState(0);

  // Design system
  const designSystem = {
    colors: {
      primary: "#E8F4FD",
      secondary: "#F0F9FF", 
      accent: "#FEF7FF",
      subtle: "#F8FAFC",
      backgrounds: {
        main: "#FEFEFE",
        cards: "#FFFFFF",
        dark: "#1E293B",
        section: "#F8FAFC",
      },
      text: {
        primary: "#1E293B",
        secondary: "#64748B",
        light: "#FFFFFF",
        muted: "#94A3B8",
      }
    }
  };

  useEffect(() => {
    setIsVisible(true);
    
    const handleScroll = () => {
      if (window.scrollY > lastScrollY && window.scrollY > 100) {
        setIsNavbarVisible(false);
      } else if (window.scrollY < lastScrollY) {
        setIsNavbarVisible(true);
      }
      setLastScrollY(window.scrollY);
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, [lastScrollY]);

  const features = [
    {
      icon: BookOpen,
      title: "Digital Notes",
      description: "Access all your study materials digitally, anytime, anywhere.",
    },
    {
      icon: Calendar,
      title: "Timetable Access", 
      description: "Never miss a class with smart timetable management.",
    },
    {
      icon: Bell,
      title: "Notice Alerts",
      description: "Stay updated with instant notifications and announcements.",
    },
    {
      icon: BarChart3,
      title: "Marks and Attendance",
      description: "Track your academic progress with detailed analytics.",
    },
  ];

  const appScreenshots = [
    {
      title: "Dashboard Overview",
      description: "Get a complete view of your academic journey at a glance"
    },
    {
      title: "Digital Notes",
      description: "Access and organize all your study materials in one place"
    },
    {
      title: "Attendance Tracking", 
      description: "Monitor your attendance with detailed insights and alerts"
    },
    {
      title: "Notice Board",
      description: "Stay updated with all college announcements and events"
    }
  ];

  const testimonials = [
    {
      name: "Sahil Tate",
      role: "Computer Engineering Student", 
      quote: "Made my college life smoother. Everything I need is just a tap away!",
      rating: 5,
    },
    {
      name: "Aditya Patil",
      role: "Mechanical Engineering Student",
      quote: "The digital notes feature saved me so much time. Highly recommended!",
      rating: 5,
    }
  ];

  const nextSlide = () => {
    setCurrentSlide((prev) => (prev + 1) % appScreenshots.length);
  };

  const prevSlide = () => {
    setCurrentSlide((prev) => (prev - 1 + appScreenshots.length) % appScreenshots.length);
  };

  const scrollToSection = (sectionId) => {
    const element = document.getElementById(sectionId);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <div className="min-h-screen relative bg-gray-50">
      {/* Floating background animations */}
      <style dangerouslySetInnerHTML={{
        __html: `
          @keyframes float {
            0%, 100% { transform: translateY(0px) rotate(0deg); }
            50% { transform: translateY(-20px) rotate(5deg); }
          }
          .float-slow { animation: float 6s ease-in-out infinite; }
          .float-medium { animation: float 4s ease-in-out infinite reverse; }
          .float-fast { animation: float 3s ease-in-out infinite; }
        `
      }} />

      {/* Background gradient overlay */}
      <div className="fixed inset-0 pointer-events-none opacity-30">
        <div className="absolute inset-0 bg-gradient-to-br from-blue-100 via-purple-50 to-pink-100"></div>
      </div>

      {/* Navigation */}
      <nav className={`fixed top-4 z-50 w-full px-4 transition-all duration-300 ${
        isNavbarVisible ? 'opacity-100 translate-y-0' : 'opacity-0 -translate-y-full'
      }`}>
        <div className="max-w-7xl mx-auto bg-white/90 backdrop-blur-md rounded-xl border border-gray-200 shadow-lg px-6 py-4">
          <div className="flex justify-between items-center">
            {/* Logo */}
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-blue-100 to-purple-100 flex items-center justify-center border">
                <Building className="w-6 h-6 text-blue-600" />
              </div>
              <div>
                <span className="font-bold text-xl text-gray-800">ClgSphere</span>
                <span className="text-xs text-gray-500 ml-2">College Portal</span>
              </div>
            </div>

            {/* Desktop Navigation */}
            <div className="hidden md:flex items-center space-x-6">
              {['About', 'Features', 'Reviews'].map((item) => (
                <button
                  key={item}
                  onClick={() => scrollToSection(item.toLowerCase())}
                  className="px-4 py-2 text-gray-600 hover:text-blue-600 font-medium transition-colors rounded-lg hover:bg-blue-50"
                >
                  {item}
                </button>
              ))}
              <button className="px-6 py-2 bg-blue-600 text-white font-semibold rounded-lg hover:bg-blue-700 transition-colors">
                Login
              </button>
            </div>

            {/* Mobile Menu Button */}
            <div className="md:hidden">
              <button
                onClick={() => setIsMenuOpen(!isMenuOpen)}
                className="p-2 rounded-lg bg-blue-50 hover:bg-blue-100 transition-colors"
              >
                {isMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
              </button>
            </div>
          </div>

          {/* Mobile Menu */}
          {isMenuOpen && (
            <div className="md:hidden mt-4 py-4 border-t border-gray-200">
              <div className="flex flex-col space-y-2">
                {['About', 'Features', 'Reviews'].map((item) => (
                  <button
                    key={item}
                    onClick={() => {
                      scrollToSection(item.toLowerCase());
                      setIsMenuOpen(false);
                    }}
                    className="px-4 py-2 text-gray-600 hover:text-blue-600 text-left"
                  >
                    {item}
                  </button>
                ))}
                <button className="px-4 py-2 bg-blue-600 text-white font-semibold rounded-lg mt-2">
                  Login
                </button>
              </div>
            </div>
          )}
        </div>
      </nav>

      {/* Hero Section */}
      <section className="pt-28 pb-16 min-h-screen flex items-center justify-center relative overflow-hidden">
        {/* Floating background elements */}
        <div className="absolute inset-0 pointer-events-none">
          <div className="absolute top-20 left-10 w-32 h-32 rounded-3xl bg-gradient-to-br from-blue-200 to-blue-300 opacity-20 float-slow"></div>
          <div className="absolute top-40 right-20 w-24 h-24 rounded-2xl bg-gradient-to-br from-purple-200 to-purple-300 opacity-15 float-medium"></div>
          <div className="absolute bottom-40 left-20 w-20 h-20 rounded-xl bg-gradient-to-br from-pink-200 to-pink-300 opacity-25 float-fast"></div>
          <div className="absolute top-60 right-40 w-16 h-16 rounded-full bg-gradient-to-br from-green-200 to-green-300 opacity-20 float-slow"></div>
        </div>

        <div className="max-w-7xl mx-auto px-6 text-center relative z-10">
          <div className={`transition-all duration-1000 ${isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'}`}>
            {/* Logo */}
            <div className="w-24 h-24 rounded-3xl bg-gradient-to-br from-white via-blue-50 to-purple-50 flex items-center justify-center mx-auto mb-8 shadow-lg border border-blue-100">
              <Building className="w-12 h-12 text-blue-600" />
            </div>

            {/* Main Heading */}
            <h1 className="text-4xl md:text-6xl lg:text-7xl font-bold mb-6 text-gray-800 leading-tight">
              Saraswati College
            </h1>
            
            <div className="bg-gradient-to-r from-blue-50 to-purple-50 px-6 py-3 rounded-2xl mb-6 border border-blue-100">
              <span className="text-xl md:text-3xl font-bold text-gray-800">Management System</span>
            </div>

            <div className="bg-gradient-to-r from-green-50 to-yellow-50 px-6 py-3 rounded-full mb-8 border border-green-100">
              <p className="text-lg font-medium text-gray-700">Your campus in your pocket ✨</p>
            </div>

            {/* Action Buttons */}
            <div className="flex flex-col sm:flex-row gap-4 justify-center mb-12">
              <button className="px-8 py-4 bg-blue-600 text-white font-semibold text-lg rounded-2xl hover:bg-blue-700 transition-all duration-300 hover:scale-105 shadow-lg">
                Login to Dashboard
              </button>
              <button 
                onClick={() => scrollToSection('app-preview')}
                className="px-8 py-4 bg-gradient-to-r from-blue-50 to-purple-50 text-gray-800 font-semibold text-lg rounded-2xl hover:shadow-lg transition-all duration-300 hover:scale-105 border border-blue-200"
              >
                Explore App 🚀
              </button>
            </div>

            {/* Stats */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-6 max-w-4xl mx-auto">
              {[
                { value: "1500+", label: "Students", bg: "from-blue-100 to-blue-200" },
                { value: "300+", label: "Faculty", bg: "from-purple-100 to-purple-200" },
                { value: "25+", label: "Years", bg: "from-green-100 to-green-200" },
                { value: "95%", label: "Placement", bg: "from-yellow-100 to-yellow-200" },
              ].map((stat, index) => (
                <div key={index} className={`p-6 rounded-2xl text-center bg-gradient-to-br ${stat.bg} shadow-md hover:shadow-lg transition-all duration-300 hover:scale-105`}>
                  <div className="text-3xl font-bold text-gray-800 mb-2">{stat.value}</div>
                  <div className="text-sm font-medium text-gray-600">{stat.label}</div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* About Section */}
      <section id="about" className="py-16 bg-gradient-to-br from-gray-50 to-blue-50">
        <div className="max-w-7xl mx-auto px-6">
          <div className="text-center mb-12">
            <div className="inline-block px-6 py-3 bg-gradient-to-r from-blue-100 to-purple-100 rounded-xl mb-6 border border-blue-200">
              <h2 className="text-3xl md:text-4xl font-bold text-gray-800">About Our College</h2>
            </div>
            <p className="text-lg text-gray-600 max-w-3xl mx-auto">
              Established in 2004, Saraswati College of Engineering has been at the forefront of technical education
            </p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            {/* Left Content */}
            <div className="space-y-6">
              {[
                { icon: Award, title: "20+ Years of Excellence", description: "Pioneering education since 2004", bg: "from-blue-100 to-blue-200" },
                { icon: Building, title: "World-Class Faculty", description: "300+ expert educators and professionals", bg: "from-purple-100 to-purple-200" },
                { icon: Target, title: "95% Placement Success", description: "Strong industry partnerships", bg: "from-green-100 to-green-200" },
              ].map((item, index) => (
                <div key={index} className={`p-6 rounded-xl bg-gradient-to-br ${item.bg} hover:scale-105 transition-all duration-300 shadow-md`}>
                  <div className="flex items-center gap-4">
                    <div className="w-12 h-12 rounded-lg bg-white/80 flex items-center justify-center">
                      <item.icon className="w-6 h-6 text-gray-700" />
                    </div>
                    <div>
                      <h3 className="text-lg font-semibold text-gray-800 mb-1">{item.title}</h3>
                      <p className="text-sm text-gray-600">{item.description}</p>
                    </div>
                  </div>
                </div>
              ))}
            </div>

            {/* Right Content - Principal's Quote */}
            <div className="p-8 rounded-xl bg-gradient-to-br from-white to-blue-50 shadow-lg border border-blue-100">
              <Quote className="w-8 h-8 mb-4 text-gray-400" />
              <p className="text-lg mb-6 italic text-gray-800">
                "Education is the most powerful weapon which you can use to change the world. At Saraswati College, we're not just teaching - we're transforming futures."
              </p>
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 rounded-full bg-gradient-to-br from-blue-100 to-purple-100 flex items-center justify-center">
                  <span className="font-semibold text-sm text-gray-700">MD</span>
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <span className="font-semibold text-sm text-gray-800">Dr. Manjusha Deshmukh</span>
                    <CheckCircle className="w-4 h-4 text-green-500" />
                  </div>
                  <p className="text-xs text-gray-600">Principal & Director</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section id="features" className="py-16">
        <div className="max-w-7xl mx-auto px-6">
          <div className="text-center mb-12">
            <div className="inline-block px-6 py-3 bg-gradient-to-r from-purple-100 to-pink-100 rounded-xl mb-6 border border-purple-200">
              <h2 className="text-3xl md:text-4xl font-bold text-gray-800">Student Benefits</h2>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {features.map((feature, index) => (
              <div key={index} className={`p-6 rounded-xl hover:scale-105 transition-all duration-300 shadow-md bg-gradient-to-br ${
                index === 0 ? 'from-blue-100 to-blue-200' :
                index === 1 ? 'from-purple-100 to-purple-200' :
                index === 2 ? 'from-green-100 to-green-200' : 'from-yellow-100 to-yellow-200'
              }`}>
                <div className="flex items-start gap-4">
                  <div className="w-12 h-12 rounded-lg bg-white/80 flex items-center justify-center flex-shrink-0">
                    <feature.icon className="w-6 h-6 text-gray-700" />
                  </div>
                  <div>
                    <h3 className="text-lg font-semibold text-gray-800 mb-2">{feature.title}</h3>
                    <p className="text-sm text-gray-600">{feature.description}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* App Preview Section */}
      <section id="app-preview" className="py-16 bg-gradient-to-br from-purple-50 to-pink-50">
        <div className="max-w-7xl mx-auto px-6">
          <div className="text-center mb-12">
            <div className="inline-block px-6 py-3 bg-gradient-to-r from-pink-100 to-purple-100 rounded-xl mb-6 border border-pink-200">
              <h2 className="text-3xl md:text-4xl font-bold text-gray-800">App Preview</h2>
            </div>
          </div>

          <div className="max-w-4xl mx-auto">
            <div className="p-8 rounded-xl bg-gradient-to-br from-white to-purple-50 shadow-lg border border-purple-100">
              <div className="text-center mb-6">
                <div className="w-full h-64 rounded-xl bg-gradient-to-br from-blue-100 to-purple-100 flex items-center justify-center mb-6 border border-blue-200">
                  <div className="text-center">
                    <div className="w-16 h-16 rounded-xl bg-white/80 flex items-center justify-center mx-auto mb-4">
                      <Building className="w-8 h-8 text-blue-600" />
                    </div>
                    <h3 className="text-xl font-semibold text-gray-800 mb-2">{appScreenshots[currentSlide].title}</h3>
                    <p className="text-sm text-gray-600">{appScreenshots[currentSlide].description}</p>
                  </div>
                </div>

                {/* Navigation Buttons */}
                <div className="flex justify-center gap-4 mb-6">
                  <button 
                    onClick={prevSlide}
                    className="p-2 rounded-lg bg-blue-100 hover:bg-blue-200 transition-colors"
                  >
                    <ChevronLeft className="w-4 h-4" />
                  </button>
                  <button 
                    onClick={nextSlide}
                    className="p-2 rounded-lg bg-blue-100 hover:bg-blue-200 transition-colors"
                  >
                    <ChevronRight className="w-4 h-4" />
                  </button>
                </div>

                {/* Dots Indicator */}
                <div className="flex justify-center gap-2">
                  {appScreenshots.map((_, index) => (
                    <button
                      key={index}
                      onClick={() => setCurrentSlide(index)}
                      className={`w-2 h-2 rounded-full transition-all duration-200 ${
                        index === currentSlide ? 'bg-gray-800' : 'bg-gray-400'
                      }`}
                    />
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Testimonials Section */}
      <section id="reviews" className="py-16">
        <div className="max-w-7xl mx-auto px-6">
          <div className="text-center mb-12">
            <div className="inline-block px-6 py-3 bg-gradient-to-r from-green-100 to-blue-100 rounded-xl mb-6 border border-green-200">
              <h2 className="text-3xl md:text-4xl font-bold text-gray-800">Success Stories</h2>
            </div>
          </div>

          <div className="max-w-3xl mx-auto">
            <div className="p-8 rounded-xl text-center bg-gradient-to-br from-white to-green-50 shadow-lg border border-green-100">
              <div className="flex justify-center mb-4">
                {[...Array(5)].map((_, i) => (
                  <Star key={i} className="w-5 h-5 text-yellow-400 fill-current" />
                ))}
              </div>
              <p className="text-lg text-gray-800 mb-6">"{testimonials[currentSlide % testimonials.length].quote}"</p>

              <div className="flex items-center justify-center gap-3">
                <div className="w-12 h-12 rounded-full bg-gradient-to-br from-blue-100 to-purple-100 flex items-center justify-center">
                  <span className="text-sm font-semibold text-gray-700">
                    {testimonials[currentSlide % testimonials.length].name.charAt(0)}
                  </span>
                </div>
                <div className="text-left">
                  <div className="flex items-center gap-2">
                    <span className="font-semibold text-sm text-gray-800">
                      {testimonials[currentSlide % testimonials.length].name}
                    </span>
                    <CheckCircle className="w-4 h-4 text-green-500" />
                  </div>
                  <p className="text-xs text-gray-600">{testimonials[currentSlide % testimonials.length].role}</p>
                </div>
              </div>

              <div className="flex justify-center gap-2 mt-6">
                {testimonials.map((_, index) => (
                  <button
                    key={index}
                    onClick={() => setCurrentSlide(index)}
                    className={`w-2 h-2 rounded-full transition-all duration-200 ${
                      (index === currentSlide % testimonials.length) ? 'bg-gray-800' : 'bg-gray-400'
                    }`}
                  />
                ))}
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 bg-gray-800">
        <div className="max-w-7xl mx-auto px-6 text-center">
          <div className="inline-block px-6 py-3 bg-gradient-to-r from-blue-100 to-purple-100 rounded-xl mb-6 border border-blue-200">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-800">Ready to Transform?</h2>
          </div>
          <p className="text-lg mb-8 max-w-2xl mx-auto text-white">
            Join thousands of students already using ClgSphere
          </p>

          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <button className="px-8 py-3 bg-white text-gray-800 font-semibold text-base rounded-xl hover:bg-gray-100 transition-colors shadow-lg">
              Get Started Today
            </button>
            <button className="px-8 py-3 bg-gradient-to-r from-blue-100 to-purple-100 text-gray-800 font-semibold text-base rounded-xl hover:shadow-lg transition-all border border-blue-200">
              Contact Support
            </button>
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section className="py-16 bg-gradient-to-br from-gray-50 to-blue-50">
        <div className="max-w-7xl mx-auto px-6">
          <div className="text-center mb-12">
            <div className="inline-block px-6 py-3 bg-gradient-to-r from-blue-100 to-green-100 rounded-xl mb-6 border border-blue-200">
              <h2 className="text-3xl md:text-4xl font-bold text-gray-800">Get in Touch</h2>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {[
              { icon: MapPin, title: "Visit Us", content: ["Saraswati College of Engineering", "Kharghar, Navi Mumbai", "Maharashtra 410210"], bg: "from-blue-100 to-blue-200" },
              { icon: Phone, title: "Call Us", content: ["+91 98765 43210", "+91 87654 32109", "Mon-Fri: 9 AM - 6 PM"], bg: "from-purple-100 to-purple-200" },
              { icon: Mail, title: "Email Us", content: ["info@saraswatice.edu.in", "support@saraswatice.edu.in", "Quick response guaranteed"], bg: "from-green-100 to-green-200" },
            ].map((contact, index) => (
              <div key={index} className={`p-6 rounded-xl text-center hover:scale-105 transition-all duration-300 shadow-md bg-gradient-to-br ${contact.bg}`}>
                <div className="w-12 h-12 rounded-lg bg-white/80 flex items-center justify-center mx-auto mb-4">
                  <contact.icon className="w-6 h-6 text-gray-700" />
                </div>
                <h3 className="text-lg font-semibold text-gray-800 mb-4">{contact.title}</h3>
                {contact.content.map((line, lineIndex) => (
                  <p key={lineIndex} className="text-sm text-gray-600 mb-1">{line}</p>
                ))}
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-12 bg-gray-800">
        <div className="max-w-7xl mx-auto px-6">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            {/* Logo and Description */}
            <div className="md:col-span-2">
              <div className="flex items-center gap-3 mb-4">
                <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-blue-100 to-purple-100 flex items-center justify-center">
                  <Building className="w-6 h-6 text-blue-600" />
                </div>
                <span className="font-bold text-xl text-white">ClgSphere</span>
              </div>
              <p className="text-sm text-gray-300 mb-6 max-w-md">
                Empowering students at Saraswati College of Engineering with digital tools for academic excellence.
              </p>
              <div className="flex gap-3">
                {[Facebook, Instagram, Linkedin, Globe].map((Icon, index) => (
                  <a key={index} href="#" className={`w-8 h-8 rounded-lg flex items-center justify-center transition-colors hover:bg-gray-700 bg-gradient-to-br ${
                    index === 0 ? 'from-blue-100 to-blue-200' :
                    index === 1 ? 'from-purple-100 to-purple-200' :
                    index === 2 ? 'from-green-100 to-green-200' : 'from-yellow-100 to-yellow-200'
                  }`}>
                    <Icon className="w-4 h-4 text-gray-700" />
                  </a>
                ))}
              </div>
            </div>

            {/* Quick Links */}
            <div>
              <h4 className="font-semibold text-sm mb-4 text-white">Quick Links</h4>
              <ul className="space-y-2">
                {['About College', 'Admissions', 'Academic Calendar', 'Placements'].map((link, index) => (
                  <li key={index}>
                    <a href="#" className="text-sm text-gray-300 hover:text-white hover:underline transition-colors">
                      {link}
                    </a>
                  </li>
                ))}
              </ul>
            </div>

            {/* Support */}
            <div>
              <h4 className="font-semibold text-sm mb-4 text-white">Support</h4>
              <ul className="space-y-2">
                {['Help Center', 'Contact Us', 'Privacy Policy', 'Terms of Service'].map((link, index) => (
                  <li key={index}>
                    <a href="#" className="text-sm text-gray-300 hover:text-white hover:underline transition-colors">
                      {link}
                    </a>
                  </li>
                ))}
              </ul>
            </div>
          </div>

          <div className="border-t border-gray-600 mt-8 pt-8 text-center">
            <p className="text-sm text-gray-300">
              © 2025 Saraswati College of Engineering. All rights reserved.
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
}