import React, { useState, useEffect } from 'react';
import { 
  Award, MapPin, Phone, Mail, Globe, Facebook, Instagram, Linkedin,
  BookOpen, Calendar, Bell, BarChart3, ChevronLeft, ChevronRight,
  Star, Quote, Menu, X, CheckCircle, Building, Target
} from 'lucide-react';

export default function LandingPage() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [currentSlide, setCurrentSlide] = useState(0);
  const [isVisible, setIsVisible] = useState(false);
  const [isNavbarVisible, setIsNavbarVisible] = useState(true);
  const [lastScrollY, setLastScrollY] = useState(0);

  // Enhanced Professional-Brutalist Design System
  const designSystem = {
    colors: {
      // More energetic yet professional palette
      primary: "#4F46E5", // Vibrant indigo
      primaryLight: "#818CF8", // Light indigo
      primaryDark: "#3730A3", // Dark indigo
      accent: "#F59E0B", // Warm amber
      accentLight: "#FCD34D", // Light amber
      secondary: "#10B981", // Emerald green
      secondaryLight: "#6EE7B7", // Light emerald
      tertiary: "#EF4444", // Vibrant red
      tertiaryLight: "#FCA5A5", // Light red
      
      // Refined backgrounds
      backgrounds: {
        main: "#FAFAFA", // Slightly warmer white
        cards: "#FFFFFF",
        dark: "#0F172A", // Deeper slate
        section: "#F8FAFC",
        gradient: "linear-gradient(135deg, #667eea 0%, #764ba2 100%)",
      },
      
      // Enhanced text colors
      text: {
        primary: "#0F172A", // Deep slate
        secondary: "#475569", // Medium slate
        light: "#FFFFFF",
        muted: "#94A3B8",
        accent: "#4F46E5",
      },
      
      // Sophisticated neutrals
      neutral: {
        50: "#F8FAFC",
        100: "#F1F5F9",
        200: "#E2E8F0",
        300: "#CBD5E1",
        400: "#94A3B8",
        500: "#64748B",
        600: "#475569",
        700: "#334155",
        800: "#1E293B",
        900: "#0F172A",
      }
    },
    
    // Enhanced shadow system for depth
    shadows: {
      xs: "0 1px 2px 0 rgba(0, 0, 0, 0.05)",
      sm: "0 1px 3px 0 rgba(0, 0, 0, 0.1), 0 1px 2px 0 rgba(0, 0, 0, 0.06)",
      md: "0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -1px rgba(0, 0, 0, 0.06)",
      lg: "0 10px 15px -3px rgba(0, 0, 0, 0.1), 0 4px 6px -2px rgba(0, 0, 0, 0.05)",
      xl: "0 20px 25px -5px rgba(0, 0, 0, 0.1), 0 10px 10px -5px rgba(0, 0, 0, 0.04)",
      "2xl": "0 25px 50px -12px rgba(0, 0, 0, 0.25)",
      
      // Brutalist shadows with color
      brutalist: {
        primary: "8px 8px 0px #4F46E5",
        accent: "6px 6px 0px #F59E0B",
        secondary: "4px 4px 0px #10B981",
        neutral: "5px 5px 0px #64748B",
        soft: "3px 3px 0px rgba(79, 70, 229, 0.3)",
      },
      
      // Glow effects
      glow: {
        primary: "0 0 20px rgba(79, 70, 229, 0.3)",
        accent: "0 0 20px rgba(245, 158, 11, 0.3)",
        secondary: "0 0 20px rgba(16, 185, 129, 0.3)",
      }
    },
    
    // Enhanced border system
    borders: {
      thin: "1px solid #E2E8F0",
      medium: "2px solid #CBD5E1",
      thick: "3px solid #94A3B8",
      accent: "2px solid #4F46E5",
      brutalist: "3px solid #0F172A",
    },
    
    // Typography system
    typography: {
      fontFamily: {
        heading: "'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif",
        body: "'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif",
        mono: "'JetBrains Mono', 'Fira Code', monospace",
      },
      fontSize: {
        xs: "0.75rem",
        sm: "0.875rem",
        base: "1rem",
        lg: "1.125rem",
        xl: "1.25rem",
        "2xl": "1.5rem",
        "3xl": "1.875rem",
        "4xl": "2.25rem",
        "5xl": "3rem",
        "6xl": "3.75rem",
        "7xl": "4.5rem",
      },
      fontWeight: {
        normal: "400",
        medium: "500",
        semibold: "600",
        bold: "700",
        extrabold: "800",
      }
    }
  };

  useEffect(() => {
    setIsVisible(true);
    
    const handleScroll = () => {
      if (window.scrollY > lastScrollY && window.scrollY > 100) {
        setIsNavbarVisible(false);
      } else if (window.scrollY < lastScrollY) {
        setIsNavbarVisible(true);
      }
      setLastScrollY(window.scrollY);
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, [lastScrollY]);

  const features = [
    {
      icon: BookOpen,
      title: "Digital Notes",
      description: "Access all your study materials digitally, anytime, anywhere.",
      color: designSystem.colors.primary,
    },
    {
      icon: Calendar,
      title: "Timetable Access", 
      description: "Never miss a class with smart timetable management.",
      color: designSystem.colors.accent,
    },
    {
      icon: Bell,
      title: "Notice Alerts",
      description: "Stay updated with instant notifications and announcements.",
      color: designSystem.colors.secondary,
    },
    {
      icon: BarChart3,
      title: "Marks and Attendance",
      description: "Track your academic progress with detailed analytics.",
      color: designSystem.colors.tertiary,
    },
  ];

  const appScreenshots = [
    {
      title: "Dashboard Overview",
      description: "Get a complete view of your academic journey at a glance"
    },
    {
      title: "Digital Notes",
      description: "Access and organize all your study materials in one place"
    },
    {
      title: "Attendance Tracking", 
      description: "Monitor your attendance with detailed insights and alerts"
    },
    {
      title: "Notice Board",
      description: "Stay updated with all college announcements and events"
    }
  ];

  const testimonials = [
    {
      name: "Sahil Tate",
      role: "Computer Engineering Student", 
      quote: "Made my college life smoother. Everything I need is just a tap away!",
      rating: 5,
    },
    {
      name: "Aditya Patil",
      role: "Mechanical Engineering Student",
      quote: "The digital notes feature saved me so much time. Highly recommended!",
      rating: 5,
    }
  ];

  const nextSlide = () => {
    setCurrentSlide((prev) => (prev + 1) % appScreenshots.length);
  };

  const prevSlide = () => {
    setCurrentSlide((prev) => (prev - 1 + appScreenshots.length) % appScreenshots.length);
  };

  const scrollToSection = (sectionId) => {
    const element = document.getElementById(sectionId);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <div className="min-h-screen relative" style={{ 
      backgroundColor: designSystem.colors.backgrounds.main,
      fontFamily: designSystem.typography.fontFamily.body 
    }}>
      {/* Enhanced CSS animations and typography */}
      <style dangerouslySetInnerHTML={{
        __html: `
          @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap');
          
          @keyframes float {
            0%, 100% { transform: translateY(0px) rotate(0deg); }
            50% { transform: translateY(-20px) rotate(5deg); }
          }
          
          @keyframes pulse-glow {
            0%, 100% { box-shadow: 0 0 20px rgba(79, 70, 229, 0.3); }
            50% { box-shadow: 0 0 30px rgba(79, 70, 229, 0.5); }
          }
          
          @keyframes slide-up {
            from { transform: translateY(20px); opacity: 0; }
            to { transform: translateY(0); opacity: 1; }
          }
          
          .float-slow { animation: float 6s ease-in-out infinite; }
          .float-medium { animation: float 4s ease-in-out infinite reverse; }
          .float-fast { animation: float 3s ease-in-out infinite; }
          .pulse-glow { animation: pulse-glow 3s ease-in-out infinite; }
          .slide-up { animation: slide-up 0.6s ease-out; }
          
          .hover-lift {
            transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
          }
          
          .hover-lift:hover {
            transform: translateY(-8px) scale(1.02);
          }
          
          .brutalist-card {
            transition: all 0.2s ease-out;
          }
          
          .brutalist-card:hover {
            transform: translate(-2px, -2px);
          }
          
          .text-gradient {
            background: linear-gradient(135deg, ${designSystem.colors.primary} 0%, ${designSystem.colors.accent} 100%);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
          }
        `
      }} />

      {/* Enhanced background with energetic gradients */}
      <div className="fixed inset-0 pointer-events-none opacity-40">
        <div 
          className="absolute inset-0"
          style={{
            background: `
              radial-gradient(circle at 20% 20%, rgba(79, 70, 229, 0.15) 0%, transparent 50%),
              radial-gradient(circle at 80% 80%, rgba(245, 158, 11, 0.12) 0%, transparent 50%),
              radial-gradient(circle at 40% 60%, rgba(16, 185, 129, 0.1) 0%, transparent 50%),
              linear-gradient(135deg, rgba(79, 70, 229, 0.05) 0%, rgba(245, 158, 11, 0.05) 100%)
            `
          }}
        />
      </div>

      {/* Enhanced Navigation with brutalist elements */}
      <nav className={`fixed top-4 z-50 w-full px-4 transition-all duration-300 ${
        isNavbarVisible ? 'opacity-100 translate-y-0' : 'opacity-0 -translate-y-full'
      }`}>
        <div 
          className="max-w-7xl mx-auto backdrop-blur-md rounded-2xl px-6 py-4 brutalist-card"
          style={{
            backgroundColor: 'rgba(255, 255, 255, 0.95)',
            border: designSystem.borders.medium,
            boxShadow: designSystem.shadows.brutalist.soft,
          }}
        >
          <div className="flex justify-between items-center">
            {/* Enhanced Logo */}
            <div className="flex items-center gap-3">
              <div 
                className="w-12 h-12 rounded-xl flex items-center justify-center hover-lift"
                style={{
                  background: `linear-gradient(135deg, ${designSystem.colors.primary} 0%, ${designSystem.colors.primaryLight} 100%)`,
                  border: designSystem.borders.thin,
                  boxShadow: designSystem.shadows.glow.primary,
                }}
              >
                <Building className="w-7 h-7 text-white" />
              </div>
              <div>
                <span 
                  className="font-bold text-xl"
                  style={{ 
                    color: designSystem.colors.text.primary,
                    fontFamily: designSystem.typography.fontFamily.heading,
                    fontWeight: designSystem.typography.fontWeight.bold
                  }}
                >
                  ClgSphere
                </span>
                <span 
                  className="text-xs ml-2"
                  style={{ color: designSystem.colors.text.muted }}
                >
                  College Portal
                </span>
              </div>
            </div>

            {/* Enhanced Desktop Navigation */}
            <div className="hidden md:flex items-center space-x-6">
              {['About', 'Features', 'Reviews'].map((item, index) => (
                <button
                  key={item}
                  onClick={() => scrollToSection(item.toLowerCase())}
                  className="px-4 py-2 font-medium transition-all duration-200 rounded-lg hover-lift"
                  style={{
                    color: designSystem.colors.text.secondary,
                    fontWeight: designSystem.typography.fontWeight.medium,
                    backgroundColor: index === 0 ? `${designSystem.colors.primary}15` : 'transparent',
                  }}
                  onMouseEnter={(e) => {
                    e.target.style.color = designSystem.colors.primary;
                    e.target.style.backgroundColor = `${designSystem.colors.primary}10`;
                  }}
                  onMouseLeave={(e) => {
                    e.target.style.color = designSystem.colors.text.secondary;
                    e.target.style.backgroundColor = index === 0 ? `${designSystem.colors.primary}15` : 'transparent';
                  }}
                >
                  {item}
                </button>
              ))}
              <button 
                className="px-6 py-2 font-semibold rounded-lg transition-all duration-200 hover-lift"
                style={{
                  background: `linear-gradient(135deg, ${designSystem.colors.primary} 0%, ${designSystem.colors.primaryDark} 100%)`,
                  color: designSystem.colors.text.light,
                  border: designSystem.borders.accent,
                  boxShadow: designSystem.shadows.brutalist.primary,
                  fontWeight: designSystem.typography.fontWeight.semibold,
                }}
              >
                Login
              </button>
            </div>

            {/* Enhanced Mobile Menu Button */}
            <div className="md:hidden">
              <button
                onClick={() => setIsMenuOpen(!isMenuOpen)}
                className="p-2 rounded-lg transition-all duration-200 hover-lift"
                style={{
                  background: `linear-gradient(135deg, ${designSystem.colors.primary}20 0%, ${designSystem.colors.primaryLight}20 100%)`,
                  border: designSystem.borders.thin,
                }}
              >
                {isMenuOpen ? 
                  <X className="w-5 h-5" style={{ color: designSystem.colors.primary }} /> : 
                  <Menu className="w-5 h-5" style={{ color: designSystem.colors.primary }} />
                }
              </button>
            </div>
          </div>

          {/* Enhanced Mobile Menu */}
          {isMenuOpen && (
            <div 
              className="md:hidden mt-4 py-4 rounded-xl slide-up"
              style={{
                backgroundColor: designSystem.colors.neutral[50],
                border: designSystem.borders.thin,
              }}
            >
              <div className="flex flex-col space-y-2">
                {['About', 'Features', 'Reviews'].map((item) => (
                  <button
                    key={item}
                    onClick={() => {
                      scrollToSection(item.toLowerCase());
                      setIsMenuOpen(false);
                    }}
                    className="px-4 py-2 text-left transition-colors rounded-lg"
                    style={{ 
                      color: designSystem.colors.text.secondary,
                      fontWeight: designSystem.typography.fontWeight.medium,
                    }}
                    onMouseEnter={(e) => {
                      e.target.style.backgroundColor = `${designSystem.colors.primary}10`;
                      e.target.style.color = designSystem.colors.primary;
                    }}
                    onMouseLeave={(e) => {
                      e.target.style.backgroundColor = 'transparent';
                      e.target.style.color = designSystem.colors.text.secondary;
                    }}
                  >
                    {item}
                  </button>
                ))}
                <button 
                  className="px-4 py-2 font-semibold rounded-lg mt-2 transition-all duration-200"
                  style={{
                    background: `linear-gradient(135deg, ${designSystem.colors.primary} 0%, ${designSystem.colors.primaryDark} 100%)`,
                    color: designSystem.colors.text.light,
                    fontWeight: designSystem.typography.fontWeight.semibold,
                  }}
                >
                  Login
                </button>
              </div>
            </div>
          )}
        </div>
      </nav>

      {/* Enhanced Hero Section */}
      <section className="pt-28 pb-16 min-h-screen flex items-center justify-center relative overflow-hidden">
        {/* Enhanced floating background elements */}
        <div className="absolute inset-0 pointer-events-none">
          <div 
            className="absolute top-20 left-10 w-32 h-32 rounded-3xl opacity-30 float-slow"
            style={{
              background: `linear-gradient(135deg, ${designSystem.colors.primary}40 0%, ${designSystem.colors.primaryLight}40 100%)`,
              filter: "blur(2px)",
            }}
          />
          <div 
            className="absolute top-40 right-20 w-24 h-24 rounded-2xl opacity-25 float-medium"
            style={{
              background: `linear-gradient(135deg, ${designSystem.colors.accent}40 0%, ${designSystem.colors.accentLight}40 100%)`,
              filter: "blur(1px)",
            }}
          />
          <div 
            className="absolute bottom-40 left-20 w-20 h-20 rounded-xl opacity-35 float-fast"
            style={{
              background: `linear-gradient(135deg, ${designSystem.colors.secondary}40 0%, ${designSystem.colors.secondaryLight}40 100%)`,
              filter: "blur(1px)",
            }}
          />
          <div 
            className="absolute top-60 right-40 w-16 h-16 rounded-full opacity-30 float-slow"
            style={{
              background: `linear-gradient(135deg, ${designSystem.colors.tertiary}40 0%, ${designSystem.colors.tertiaryLight}40 100%)`,
            }}
          />
        </div>

        <div className="max-w-7xl mx-auto px-6 text-center relative z-10">
          <div className={`transition-all duration-1000 ${isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'}`}>
            {/* Enhanced Logo */}
            <div 
              className="w-28 h-28 rounded-3xl flex items-center justify-center mx-auto mb-8 hover-lift pulse-glow"
              style={{
                background: `linear-gradient(135deg, ${designSystem.colors.backgrounds.cards} 0%, ${designSystem.colors.neutral[50]} 100%)`,
                border: `3px solid ${designSystem.colors.primary}`,
                boxShadow: `${designSystem.shadows.xl}, ${designSystem.shadows.glow.primary}`,
              }}
            >
              <Building 
                className="w-14 h-14"
                style={{ color: designSystem.colors.primary }}
              />
            </div>

            {/* Enhanced Main Heading */}
            <h1 
              className="text-4xl md:text-6xl lg:text-7xl font-bold mb-6 leading-tight"
              style={{ 
                color: designSystem.colors.text.primary,
                fontFamily: designSystem.typography.fontFamily.heading,
                fontWeight: designSystem.typography.fontWeight.extrabold,
              }}
            >
              Saraswati College
            </h1>
            
            <div 
              className="px-6 py-3 rounded-2xl mb-6 brutalist-card"
              style={{
                background: `linear-gradient(135deg, ${designSystem.colors.primary}15 0%, ${designSystem.colors.accent}10 100%)`,
                border: `2px solid ${designSystem.colors.primary}`,
                boxShadow: designSystem.shadows.brutalist.primary,
              }}
            >
              <span 
                className="text-xl md:text-3xl font-bold text-gradient"
                style={{ fontWeight: designSystem.typography.fontWeight.bold }}
              >
                Management System
              </span>
            </div>

            <div 
              className="px-6 py-3 rounded-full mb-8 hover-lift"
              style={{
                background: `linear-gradient(135deg, ${designSystem.colors.secondary}20 0%, ${designSystem.colors.accent}15 100%)`,
                border: `2px solid ${designSystem.colors.secondary}`,
                boxShadow: designSystem.shadows.brutalist.secondary,
              }}
            >
              <p 
                className="text-lg font-medium"
                style={{ 
                  color: designSystem.colors.text.primary,
                  fontWeight: designSystem.typography.fontWeight.medium,
                }}
              >
                Your campus in your pocket ✨
              </p>
            </div>

            {/* Enhanced Action Buttons */}
            <div className="flex flex-col sm:flex-row gap-4 justify-center mb-12">
              <button 
                className="px-8 py-4 font-semibold text-lg rounded-2xl transition-all duration-300 hover-lift brutalist-card"
                style={{
                  background: `linear-gradient(135deg, ${designSystem.colors.primary} 0%, ${designSystem.colors.primaryDark} 100%)`,
                  color: designSystem.colors.text.light,
                  border: `3px solid ${designSystem.colors.primaryDark}`,
                  boxShadow: designSystem.shadows.brutalist.primary,
                  fontWeight: designSystem.typography.fontWeight.semibold,
                }}
              >
                Login to Dashboard
              </button>
              <button 
                onClick={() => scrollToSection('app-preview')}
                className="px-8 py-4 font-semibold text-lg rounded-2xl transition-all duration-300 hover-lift brutalist-card"
                style={{
                  background: `linear-gradient(135deg, ${designSystem.colors.backgrounds.cards} 0%, ${designSystem.colors.neutral[50]} 100%)`,
                  color: designSystem.colors.text.primary,
                  border: `3px solid ${designSystem.colors.accent}`,
                  boxShadow: designSystem.shadows.brutalist.accent,
                  fontWeight: designSystem.typography.fontWeight.semibold,
                }}
              >
                Explore App 🚀
              </button>
            </div>

            {/* Enhanced Stats */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-6 max-w-4xl mx-auto">
              {[
                { value: "1500+", label: "Students", color: designSystem.colors.primary },
                { value: "300+", label: "Faculty", color: designSystem.colors.accent },
                { value: "25+", label: "Years", color: designSystem.colors.secondary },
                { value: "95%", label: "Placement", color: designSystem.colors.tertiary },
              ].map((stat, index) => (
                <div 
                  key={index} 
                  className="p-6 rounded-2xl text-center transition-all duration-300 hover-lift brutalist-card"
                  style={{
                    background: `linear-gradient(135deg, ${stat.color}15 0%, ${stat.color}10 100%)`,
                    border: `2px solid ${stat.color}`,
                    boxShadow: `4px 4px 0px ${stat.color}`,
                  }}
                >
                  <div 
                    className="text-3xl font-bold mb-2"
                    style={{ 
                      color: stat.color,
                      fontWeight: designSystem.typography.fontWeight.bold,
                    }}
                  >
                    {stat.value}
                  </div>
                  <div 
                    className="text-sm font-medium"
                    style={{ 
                      color: designSystem.colors.text.secondary,
                      fontWeight: designSystem.typography.fontWeight.medium,
                    }}
                  >
                    {stat.label}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Enhanced About Section */}
      <section 
        id="about" 
        className="py-16 relative"
        style={{
          background: `linear-gradient(135deg, ${designSystem.colors.neutral[50]} 0%, ${designSystem.colors.primary}05 100%)`,
        }}
      >
        <div className="max-w-7xl mx-auto px-6">
          <div className="text-center mb-12">
            <div 
              className="inline-block px-6 py-3 rounded-xl mb-6 brutalist-card"
              style={{
                background: `linear-gradient(135deg, ${designSystem.colors.primary}20 0%, ${designSystem.colors.accent}15 100%)`,
                border: `2px solid ${designSystem.colors.primary}`,
                boxShadow: designSystem.shadows.brutalist.primary,
              }}
            >
              <h2 
                className="text-3xl md:text-4xl font-bold"
                style={{ 
                  color: designSystem.colors.text.primary,
                  fontFamily: designSystem.typography.fontFamily.heading,
                  fontWeight: designSystem.typography.fontWeight.bold,
                }}
              >
                About Our College
              </h2>
            </div>
            <p 
              className="text-lg max-w-3xl mx-auto"
              style={{ 
                color: designSystem.colors.text.secondary,
                fontWeight: designSystem.typography.fontWeight.normal,
              }}
            >
              Established in 2004, Saraswati College of Engineering has been at the forefront of technical education
            </p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            {/* Enhanced Left Content */}
            <div className="space-y-6">
              {[
                { icon: Award, title: "20+ Years of Excellence", description: "Pioneering education since 2004", color: designSystem.colors.primary },
                { icon: Building, title: "World-Class Faculty", description: "300+ expert educators and professionals", color: designSystem.colors.accent },
                { icon: Target, title: "95% Placement Success", description: "Strong industry partnerships", color: designSystem.colors.secondary },
              ].map((item, index) => (
                <div 
                  key={index} 
                  className="p-6 rounded-xl transition-all duration-300 hover-lift brutalist-card"
                  style={{
                    background: `linear-gradient(135deg, ${item.color}15 0%, ${item.color}10 100%)`,
                    border: `2px solid ${item.color}`,
                    boxShadow: `4px 4px 0px ${item.color}`,
                  }}
                >
                  <div className="flex items-center gap-4">
                    <div 
                      className="w-12 h-12 rounded-lg flex items-center justify-center"
                      style={{
                        background: `linear-gradient(135deg, ${item.color} 0%, ${item.color}CC 100%)`,
                        boxShadow: designSystem.shadows.sm,
                      }}
                    >
                      <item.icon className="w-6 h-6 text-white" />
                    </div>
                    <div>
                      <h3 
                        className="text-lg font-semibold mb-1"
                        style={{ 
                          color: designSystem.colors.text.primary,
                          fontWeight: designSystem.typography.fontWeight.semibold,
                        }}
                      >
                        {item.title}
                      </h3>
                      <p 
                        className="text-sm"
                        style={{ color: designSystem.colors.text.secondary }}
                      >
                        {item.description}
                      </p>
                    </div>
                  </div>
                </div>
              ))}
            </div>

            {/* Enhanced Right Content - Principal's Quote */}
            <div 
              className="p-8 rounded-xl brutalist-card"
              style={{
                background: `linear-gradient(135deg, ${designSystem.colors.backgrounds.cards} 0%, ${designSystem.colors.neutral[50]} 100%)`,
                border: `3px solid ${designSystem.colors.primary}`,
                boxShadow: designSystem.shadows.brutalist.primary,
              }}
            >
              <Quote 
                className="w-8 h-8 mb-4"
                style={{ color: designSystem.colors.text.muted }}
              />
              <p 
                className="text-lg mb-6 italic"
                style={{ 
                  color: designSystem.colors.text.primary,
                  fontWeight: designSystem.typography.fontWeight.normal,
                }}
              >
                "Education is the most powerful weapon which you can use to change the world. At Saraswati College, we're not just teaching - we're transforming futures."
              </p>
              <div className="flex items-center gap-3">
                <div 
                  className="w-12 h-12 rounded-full flex items-center justify-center"
                  style={{
                    background: `linear-gradient(135deg, ${designSystem.colors.primary} 0%, ${designSystem.colors.primaryLight} 100%)`,
                  }}
                >
                  <span 
                    className="font-semibold text-sm text-white"
                    style={{ fontWeight: designSystem.typography.fontWeight.semibold }}
                  >
                    MD
                  </span>
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <span 
                      className="font-semibold text-sm"
                      style={{ 
                        color: designSystem.colors.text.primary,
                        fontWeight: designSystem.typography.fontWeight.semibold,
                      }}
                    >
                      Dr. Manjusha Deshmukh
                    </span>
                    <CheckCircle 
                      className="w-4 h-4"
                      style={{ color: designSystem.colors.secondary }}
                    />
                  </div>
                  <p 
                    className="text-xs"
                    style={{ color: designSystem.colors.text.secondary }}
                  >
                    Principal & Director
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Enhanced Features Section */}
      <section id="features" className="py-16">
        <div className="max-w-7xl mx-auto px-6">
          <div className="text-center mb-12">
            <div 
              className="inline-block px-6 py-3 rounded-xl mb-6 brutalist-card"
              style={{
                background: `linear-gradient(135deg, ${designSystem.colors.accent}20 0%, ${designSystem.colors.secondary}15 100%)`,
                border: `2px solid ${designSystem.colors.accent}`,
                boxShadow: designSystem.shadows.brutalist.accent,
              }}
            >
              <h2 
                className="text-3xl md:text-4xl font-bold"
                style={{ 
                  color: designSystem.colors.text.primary,
                  fontFamily: designSystem.typography.fontFamily.heading,
                  fontWeight: designSystem.typography.fontWeight.bold,
                }}
              >
                Student Benefits
              </h2>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {features.map((feature, index) => (
              <div 
                key={index} 
                className="p-6 rounded-xl transition-all duration-300 hover-lift brutalist-card"
                style={{
                  background: `linear-gradient(135deg, ${feature.color}15 0%, ${feature.color}10 100%)`,
                  border: `2px solid ${feature.color}`,
                  boxShadow: `4px 4px 0px ${feature.color}`,
                }}
              >
                <div className="flex items-start gap-4">
                  <div 
                    className="w-12 h-12 rounded-lg flex items-center justify-center flex-shrink-0"
                    style={{
                      background: `linear-gradient(135deg, ${feature.color} 0%, ${feature.color}CC 100%)`,
                      boxShadow: designSystem.shadows.sm,
                    }}
                  >
                    <feature.icon className="w-6 h-6 text-white" />
                  </div>
                  <div>
                    <h3 
                      className="text-lg font-semibold mb-2"
                      style={{ 
                        color: designSystem.colors.text.primary,
                        fontWeight: designSystem.typography.fontWeight.semibold,
                      }}
                    >
                      {feature.title}
                    </h3>
                    <p 
                      className="text-sm"
                      style={{ color: designSystem.colors.text.secondary }}
                    >
                      {feature.description}
                    </p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Enhanced App Preview Section */}
      <section 
        id="app-preview" 
        className="py-16"
        style={{
          background: `linear-gradient(135deg, ${designSystem.colors.tertiary}05 0%, ${designSystem.colors.accent}05 100%)`,
        }}
      >
        <div className="max-w-7xl mx-auto px-6">
          <div className="text-center mb-12">
            <div 
              className="inline-block px-6 py-3 rounded-xl mb-6 brutalist-card"
              style={{
                background: `linear-gradient(135deg, ${designSystem.colors.tertiary}20 0%, ${designSystem.colors.accent}15 100%)`,
                border: `2px solid ${designSystem.colors.tertiary}`,
                boxShadow: designSystem.shadows.brutalist.accent,
              }}
            >
              <h2 
                className="text-3xl md:text-4xl font-bold"
                style={{ 
                  color: designSystem.colors.text.primary,
                  fontFamily: designSystem.typography.fontFamily.heading,
                  fontWeight: designSystem.typography.fontWeight.bold,
                }}
              >
                App Preview
              </h2>
            </div>
          </div>

          <div className="max-w-4xl mx-auto">
            <div 
              className="p-8 rounded-xl brutalist-card"
              style={{
                background: `linear-gradient(135deg, ${designSystem.colors.backgrounds.cards} 0%, ${designSystem.colors.neutral[50]} 100%)`,
                border: `3px solid ${designSystem.colors.primary}`,
                boxShadow: designSystem.shadows.brutalist.primary,
              }}
            >
              <div className="text-center mb-6">
                <div 
                  className="w-full h-64 rounded-xl flex items-center justify-center mb-6"
                  style={{
                    background: `linear-gradient(135deg, ${designSystem.colors.primary}20 0%, ${designSystem.colors.accent}15 100%)`,
                    border: `2px solid ${designSystem.colors.primary}`,
                  }}
                >
                  <div className="text-center">
                    <div 
                      className="w-16 h-16 rounded-xl flex items-center justify-center mx-auto mb-4"
                      style={{
                        background: `linear-gradient(135deg, ${designSystem.colors.primary} 0%, ${designSystem.colors.primaryLight} 100%)`,
                        boxShadow: designSystem.shadows.glow.primary,
                      }}
                    >
                      <Building className="w-8 h-8 text-white" />
                    </div>
                    <h3 
                      className="text-xl font-semibold mb-2"
                      style={{ 
                        color: designSystem.colors.text.primary,
                        fontWeight: designSystem.typography.fontWeight.semibold,
                      }}
                    >
                      {appScreenshots[currentSlide].title}
                    </h3>
                    <p 
                      className="text-sm"
                      style={{ color: designSystem.colors.text.secondary }}
                    >
                      {appScreenshots[currentSlide].description}
                    </p>
                  </div>
                </div>

                {/* Enhanced Navigation Buttons */}
                <div className="flex justify-center gap-4 mb-6">
                  <button 
                    onClick={prevSlide}
                    className="p-2 rounded-lg transition-all duration-200 hover-lift"
                    style={{
                      background: `linear-gradient(135deg, ${designSystem.colors.primary}20 0%, ${designSystem.colors.primaryLight}20 100%)`,
                      border: `2px solid ${designSystem.colors.primary}`,
                      color: designSystem.colors.primary,
                    }}
                  >
                    <ChevronLeft className="w-4 h-4" />
                  </button>
                  <button 
                    onClick={nextSlide}
                    className="p-2 rounded-lg transition-all duration-200 hover-lift"
                    style={{
                      background: `linear-gradient(135deg, ${designSystem.colors.primary}20 0%, ${designSystem.colors.primaryLight}20 100%)`,
                      border: `2px solid ${designSystem.colors.primary}`,
                      color: designSystem.colors.primary,
                    }}
                  >
                    <ChevronRight className="w-4 h-4" />
                  </button>
                </div>

                {/* Enhanced Dots Indicator */}
                <div className="flex justify-center gap-2">
                  {appScreenshots.map((_, index) => (
                    <button
                      key={index}
                      onClick={() => setCurrentSlide(index)}
                      className="w-3 h-3 rounded-full transition-all duration-200"
                      style={{
                        backgroundColor: index === currentSlide ? designSystem.colors.primary : designSystem.colors.neutral[300],
                        border: `1px solid ${designSystem.colors.primary}`,
                      }}
                    />
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Enhanced Testimonials Section */}
      <section id="reviews" className="py-16">
        <div className="max-w-7xl mx-auto px-6">
          <div className="text-center mb-12">
            <div 
              className="inline-block px-6 py-3 rounded-xl mb-6 brutalist-card"
              style={{
                background: `linear-gradient(135deg, ${designSystem.colors.secondary}20 0%, ${designSystem.colors.primary}15 100%)`,
                border: `2px solid ${designSystem.colors.secondary}`,
                boxShadow: designSystem.shadows.brutalist.secondary,
              }}
            >
              <h2 
                className="text-3xl md:text-4xl font-bold"
                style={{ 
                  color: designSystem.colors.text.primary,
                  fontFamily: designSystem.typography.fontFamily.heading,
                  fontWeight: designSystem.typography.fontWeight.bold,
                }}
              >
                Success Stories
              </h2>
            </div>
          </div>

          <div className="max-w-3xl mx-auto">
            <div 
              className="p-8 rounded-xl text-center brutalist-card"
              style={{
                background: `linear-gradient(135deg, ${designSystem.colors.backgrounds.cards} 0%, ${designSystem.colors.neutral[50]} 100%)`,
                border: `3px solid ${designSystem.colors.secondary}`,
                boxShadow: designSystem.shadows.brutalist.secondary,
              }}
            >
              <div className="flex justify-center mb-4">
                {[...Array(5)].map((_, i) => (
                  <Star 
                    key={i} 
                    className="w-5 h-5 fill-current"
                    style={{ color: designSystem.colors.accent }}
                  />
                ))}
              </div>
              <p 
                className="text-lg mb-6"
                style={{ 
                  color: designSystem.colors.text.primary,
                  fontWeight: designSystem.typography.fontWeight.normal,
                }}
              >
                "{testimonials[currentSlide % testimonials.length].quote}"
              </p>

              <div className="flex items-center justify-center gap-3">
                <div 
                  className="w-12 h-12 rounded-full flex items-center justify-center"
                  style={{
                    background: `linear-gradient(135deg, ${designSystem.colors.secondary} 0%, ${designSystem.colors.secondaryLight} 100%)`,
                  }}
                >
                  <span 
                    className="text-sm font-semibold text-white"
                    style={{ fontWeight: designSystem.typography.fontWeight.semibold }}
                  >
                    {testimonials[currentSlide % testimonials.length].name.charAt(0)}
                  </span>
                </div>
                <div className="text-left">
                  <div className="flex items-center gap-2">
                    <span 
                      className="font-semibold text-sm"
                      style={{ 
                        color: designSystem.colors.text.primary,
                        fontWeight: designSystem.typography.fontWeight.semibold,
                      }}
                    >
                      {testimonials[currentSlide % testimonials.length].name}
                    </span>
                    <CheckCircle 
                      className="w-4 h-4"
                      style={{ color: designSystem.colors.secondary }}
                    />
                  </div>
                  <p 
                    className="text-xs"
                    style={{ color: designSystem.colors.text.secondary }}
                  >
                    {testimonials[currentSlide % testimonials.length].role}
                  </p>
                </div>
              </div>

              <div className="flex justify-center gap-2 mt-6">
                {testimonials.map((_, index) => (
                  <button
                    key={index}
                    onClick={() => setCurrentSlide(index)}
                    className="w-3 h-3 rounded-full transition-all duration-200"
                    style={{
                      backgroundColor: (index === currentSlide % testimonials.length) ? designSystem.colors.secondary : designSystem.colors.neutral[300],
                      border: `1px solid ${designSystem.colors.secondary}`,
                    }}
                  />
                ))}
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Enhanced CTA Section */}
      <section 
        className="py-16"
        style={{ backgroundColor: designSystem.colors.backgrounds.dark }}
      >
        <div className="max-w-7xl mx-auto px-6 text-center">
          <div 
            className="inline-block px-6 py-3 rounded-xl mb-6 brutalist-card"
            style={{
              background: `linear-gradient(135deg, ${designSystem.colors.backgrounds.cards} 0%, ${designSystem.colors.neutral[100]} 100%)`,
              border: `3px solid ${designSystem.colors.accent}`,
              boxShadow: designSystem.shadows.brutalist.accent,
            }}
          >
            <h2 
              className="text-3xl md:text-4xl font-bold"
              style={{ 
                color: designSystem.colors.text.primary,
                fontFamily: designSystem.typography.fontFamily.heading,
                fontWeight: designSystem.typography.fontWeight.bold,
              }}
            >
              Ready to Transform?
            </h2>
          </div>
          <p 
            className="text-lg mb-8 max-w-2xl mx-auto"
            style={{ 
              color: designSystem.colors.text.light,
              fontWeight: designSystem.typography.fontWeight.normal,
            }}
          >
            Join thousands of students already using ClgSphere
          </p>

          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <button 
              className="px-8 py-3 font-semibold text-base rounded-xl transition-all duration-200 hover-lift brutalist-card"
              style={{
                background: `linear-gradient(135deg, ${designSystem.colors.backgrounds.cards} 0%, ${designSystem.colors.neutral[100]} 100%)`,
                color: designSystem.colors.text.primary,
                border: `3px solid ${designSystem.colors.primary}`,
                boxShadow: designSystem.shadows.brutalist.primary,
                fontWeight: designSystem.typography.fontWeight.semibold,
              }}
            >
              Get Started Today
            </button>
            <button 
              className="px-8 py-3 font-semibold text-base rounded-xl transition-all duration-200 hover-lift brutalist-card"
              style={{
                background: `linear-gradient(135deg, ${designSystem.colors.accent}20 0%, ${designSystem.colors.secondary}15 100%)`,
                color: designSystem.colors.text.light,
                border: `3px solid ${designSystem.colors.accent}`,
                boxShadow: designSystem.shadows.brutalist.accent,
                fontWeight: designSystem.typography.fontWeight.semibold,
              }}
            >
              Contact Support
            </button>
          </div>
        </div>
      </section>

      {/* Enhanced Contact Section */}
      <section 
        className="py-16"
        style={{
          background: `linear-gradient(135deg, ${designSystem.colors.neutral[50]} 0%, ${designSystem.colors.secondary}05 100%)`,
        }}
      >
        <div className="max-w-7xl mx-auto px-6">
          <div className="text-center mb-12">
            <div 
              className="inline-block px-6 py-3 rounded-xl mb-6 brutalist-card"
              style={{
                background: `linear-gradient(135deg, ${designSystem.colors.secondary}20 0%, ${designSystem.colors.primary}15 100%)`,
                border: `2px solid ${designSystem.colors.secondary}`,
                boxShadow: designSystem.shadows.brutalist.secondary,
              }}
            >
              <h2 
                className="text-3xl md:text-4xl font-bold"
                style={{ 
                  color: designSystem.colors.text.primary,
                  fontFamily: designSystem.typography.fontFamily.heading,
                  fontWeight: designSystem.typography.fontWeight.bold,
                }}
              >
                Get in Touch
              </h2>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {[
              { icon: MapPin, title: "Visit Us", content: ["Saraswati College of Engineering", "Kharghar, Navi Mumbai", "Maharashtra 410210"], color: designSystem.colors.primary },
              { icon: Phone, title: "Call Us", content: ["+91 98765 43210", "+91 87654 32109", "Mon-Fri: 9 AM - 6 PM"], color: designSystem.colors.accent },
              { icon: Mail, title: "Email Us", content: ["info@saraswatice.edu.in", "support@saraswatice.edu.in", "Quick response guaranteed"], color: designSystem.colors.secondary },
            ].map((contact, index) => (
              <div 
                key={index} 
                className="p-6 rounded-xl text-center transition-all duration-300 hover-lift brutalist-card"
                style={{
                  background: `linear-gradient(135deg, ${contact.color}15 0%, ${contact.color}10 100%)`,
                  border: `2px solid ${contact.color}`,
                  boxShadow: `4px 4px 0px ${contact.color}`,
                }}
              >
                <div 
                  className="w-12 h-12 rounded-lg flex items-center justify-center mx-auto mb-4"
                  style={{
                    background: `linear-gradient(135deg, ${contact.color} 0%, ${contact.color}CC 100%)`,
                    boxShadow: designSystem.shadows.sm,
                  }}
                >
                  <contact.icon className="w-6 h-6 text-white" />
                </div>
                <h3 
                  className="text-lg font-semibold mb-4"
                  style={{ 
                    color: designSystem.colors.text.primary,
                    fontWeight: designSystem.typography.fontWeight.semibold,
                  }}
                >
                  {contact.title}
                </h3>
                {contact.content.map((line, lineIndex) => (
                  <p 
                    key={lineIndex} 
                    className="text-sm mb-1"
                    style={{ color: designSystem.colors.text.secondary }}
                  >
                    {line}
                  </p>
                ))}
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Enhanced Footer */}
      <footer 
        className="py-12"
        style={{ backgroundColor: designSystem.colors.backgrounds.dark }}
      >
        <div className="max-w-7xl mx-auto px-6">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            {/* Enhanced Logo and Description */}
            <div className="md:col-span-2">
              <div className="flex items-center gap-3 mb-4">
                <div 
                  className="w-10 h-10 rounded-lg flex items-center justify-center"
                  style={{
                    background: `linear-gradient(135deg, ${designSystem.colors.primary} 0%, ${designSystem.colors.primaryLight} 100%)`,
                  }}
                >
                  <Building className="w-6 h-6 text-white" />
                </div>
                <span 
                  className="font-bold text-xl"
                  style={{ 
                    color: designSystem.colors.text.light,
                    fontFamily: designSystem.typography.fontFamily.heading,
                    fontWeight: designSystem.typography.fontWeight.bold,
                  }}
                >
                  ClgSphere
                </span>
              </div>
              <p 
                className="text-sm mb-6 max-w-md"
                style={{ color: designSystem.colors.neutral[300] }}
              >
                Empowering students at Saraswati College of Engineering with digital tools for academic excellence.
              </p>
              <div className="flex gap-3">
                {[
                  { Icon: Facebook, color: designSystem.colors.primary },
                  { Icon: Instagram, color: designSystem.colors.accent },
                  { Icon: Linkedin, color: designSystem.colors.secondary },
                  { Icon: Globe, color: designSystem.colors.tertiary },
                ].map(({ Icon, color }, index) => (
                  <a 
                    key={index} 
                    href="#" 
                    className="w-8 h-8 rounded-lg flex items-center justify-center transition-all duration-200 hover-lift"
                    style={{
                      background: `linear-gradient(135deg, ${color}20 0%, ${color}15 100%)`,
                      border: `1px solid ${color}`,
                    }}
                    onMouseEnter={(e) => {
                      e.target.style.backgroundColor = color;
                    }}
                    onMouseLeave={(e) => {
                      e.target.style.background = `linear-gradient(135deg, ${color}20 0%, ${color}15 100%)`;
                    }}
                  >
                    <Icon 
                      className="w-4 h-4"
                      style={{ color: designSystem.colors.text.light }}
                    />
                  </a>
                ))}
              </div>
            </div>

            {/* Enhanced Quick Links */}
            <div>
              <h4 
                className="font-semibold text-sm mb-4"
                style={{ 
                  color: designSystem.colors.text.light,
                  fontWeight: designSystem.typography.fontWeight.semibold,
                }}
              >
                Quick Links
              </h4>
              <ul className="space-y-2">
                {['About College', 'Admissions', 'Academic Calendar', 'Placements'].map((link, index) => (
                  <li key={index}>
                    <a 
                      href="#" 
                      className="text-sm transition-colors"
                      style={{ color: designSystem.colors.neutral[300] }}
                      onMouseEnter={(e) => {
                        e.target.style.color = designSystem.colors.primary;
                      }}
                      onMouseLeave={(e) => {
                        e.target.style.color = designSystem.colors.neutral[300];
                      }}
                    >
                      {link}
                    </a>
                  </li>
                ))}
              </ul>
            </div>

            {/* Enhanced Support */}
            <div>
              <h4 
                className="font-semibold text-sm mb-4"
                style={{ 
                  color: designSystem.colors.text.light,
                  fontWeight: designSystem.typography.fontWeight.semibold,
                }}
              >
                Support
              </h4>
              <ul className="space-y-2">
                {['Help Center', 'Contact Us', 'Privacy Policy', 'Terms of Service'].map((link, index) => (
                  <li key={index}>
                    <a 
                      href="#" 
                      className="text-sm transition-colors"
                      style={{ color: designSystem.colors.neutral[300] }}
                      onMouseEnter={(e) => {
                        e.target.style.color = designSystem.colors.primary;
                      }}
                      onMouseLeave={(e) => {
                        e.target.style.color = designSystem.colors.neutral[300];
                      }}
                    >
                      {link}
                    </a>
                  </li>
                ))}
              </ul>
            </div>
          </div>

          <div 
            className="mt-8 pt-8 text-center"
            style={{ borderTop: `1px solid ${designSystem.colors.neutral[600]}` }}
          >
            <p 
              className="text-sm"
              style={{ color: designSystem.colors.neutral[300] }}
            >
              © 2025 Saraswati College of Engineering. All rights reserved.
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
}