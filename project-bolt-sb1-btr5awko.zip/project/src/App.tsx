import React from 'react';
import LandingPage from './college-landing-page';

function App() {
  return <LandingPage />;
}

export default App;