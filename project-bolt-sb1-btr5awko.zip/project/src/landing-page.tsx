"use client"

import { Button } from "@/components/ui/button"
import {
  Award,
  MapPin,
  Phone,
  Mail,
  Globe,
  Facebook,
  Instagram,
  Linkedin,
  BookOpen,
  Calendar,
  Bell,
  BarChart3,
  ChevronLeft,
  ChevronRight,
  Star,
  Quote,
  Menu,
  X,
  CheckCircle,
  Building,
  Target,
} from "lucide-react"
import { useState, useEffect } from "react"
import Link from "next/link"
import BlurryBlob from "@/components/mage-ui/background/blurry-blob"
import CountUp from "@/components/ui/CountUp"
import SplitText from "@/components/animations/SplitText"
import Image from "next/image"

export default function LandingPage() {
  ;<style jsx global>{`
        @keyframes float {
          0%, 100% { transform: translateY(0px) rotate(0deg); }
          50% { transform: translateY(-20px) rotate(5deg); }
        }
      `}</style>
  const [isMenuOpen, setIsMenuOpen] = useState(false)
  const [currentSlide, setCurrentSlide] = useState(0)
  const [isVisible, setIsVisible] = useState(false)
  const [isNavbarVisible, setIsNavbarVisible] = useState(true)
  const [lastScrollY, setLastScrollY] = useState(0)

  // Balanced Professional-Brutalist Design System
  const designSystem = {
    colors: {
      primary: "#E8F4FD", // Very soft blue
      secondary: "#F0F9FF", // Almost white blue
      accent: "#FEF7FF", // Very soft purple
      subtle: "#F8FAFC", // Almost white with hint of blue
      backgrounds: {
        main: "#FEFEFE",
        cards: "#FFFFFF",
        dark: "#1E293B",
        section: "#F8FAFC",
      },
      text: {
        primary: "#1E293B",
        secondary: "#64748B",
        light: "#FFFFFF",
        muted: "#94A3B8",
      },
      borders: {
        light: "1px solid #E2E8F0",
        medium: "2px solid #CBD5E1",
        accent: "2px solid #E8F4FD",
      },
    },
    shadows: {
      soft: "0 1px 3px 0 rgba(0, 0, 0, 0.1), 0 1px 2px 0 rgba(0, 0, 0, 0.06)",
      medium: "0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -1px rgba(0, 0, 0, 0.06)",
      large: "0 10px 15px -3px rgba(0, 0, 0, 0.1), 0 4px 6px -2px rgba(0, 0, 0, 0.05)",
      brutalist: "4px 4px 0px rgba(30, 41, 59, 0.1)",
    },
  }

  useEffect(() => {
    setIsVisible(true)

    const handleScroll = () => {
      if (window.scrollY > lastScrollY && window.scrollY > 100) {
        setIsNavbarVisible(false)
      } else if (window.scrollY < lastScrollY) {
        setIsNavbarVisible(true)
      }
      setLastScrollY(window.scrollY)
    }

    window.addEventListener("scroll", handleScroll)
    return () => window.removeEventListener("scroll", handleScroll)
  }, [lastScrollY])

  const features = [
    {
      icon: BookOpen,
      title: "Digital Notes",
      description: "Access all your study materials digitally, anytime, anywhere.",
    },
    {
      icon: Calendar,
      title: "Timetable Access",
      description: "Never miss a class with smart timetable management.",
    },
    {
      icon: Bell,
      title: "Notice Alerts",
      description: "Stay updated with instant notifications and announcements.",
    },
    {
      icon: BarChart3,
      title: "Marks and Attendance",
      description: "Track your academic progress with detailed analytics.",
    },
  ]

  const appScreenshots = [
    {
      title: "Dashboard Overview",
      description: "Get a complete view of your academic journey at a glance",
    },
    {
      title: "Digital Notes",
      description: "Access and organize all your study materials in one place",
    },
    {
      title: "Attendance Tracking",
      description: "Monitor your attendance with detailed insights and alerts",
    },
    {
      title: "Notice Board",
      description: "Stay updated with all college announcements and events",
    },
  ]

  const testimonials = [
    {
      name: "Sahil Tate",
      role: "Computer Engineering Student",
      quote: "Made my college life smoother. Everything I need is just a tap away!",
      rating: 5,
    },
    {
      name: "Aditya Patil",
      role: "Mechanical Engineering Student",
      quote: "The digital notes feature saved me so much time. Highly recommended!",
      rating: 5,
    },
  ]

  const nextSlide = () => {
    setCurrentSlide((prev) => (prev + 1) % appScreenshots.length)
  }

  const prevSlide = () => {
    setCurrentSlide((prev) => (prev - 1 + appScreenshots.length) % appScreenshots.length)
  }

  const scrollToSection = (sectionId: string) => {
    const element = document.getElementById(sectionId)
    if (element) {
      element.scrollIntoView({ behavior: "smooth" })
    }
  }

  return (
    <div className="min-h-screen relative">
      {/* Subtle Background Gradient */}
      <div
        className="fixed inset-0 pointer-events-none"
        style={{
          background: `
            radial-gradient(circle at 20% 20%, rgba(232, 244, 253, 0.3) 0%, transparent 50%),
            radial-gradient(circle at 80% 80%, rgba(254, 247, 255, 0.2) 0%, transparent 50%),
            radial-gradient(circle at 40% 60%, rgba(240, 249, 255, 0.25) 0%, transparent 50%),
            linear-gradient(135deg, rgba(232, 244, 253, 0.1) 0%, rgba(254, 247, 255, 0.1) 100%)
          `,
        }}
      />

      {/* Main Content */}
      <div className="relative z-10" style={{ backgroundColor: "rgba(254, 254, 254, 0.8)" }}>
        {/* Professional Navigation with Subtle Brutalist Touch */}
        <nav
          className={`fixed top-4 sm:top-6 z-50 w-[calc(100%-1rem)] sm:w-[calc(100%-2rem)] left-1/2 -translate-x-1/2 transition-all duration-300 ${
            isNavbarVisible ? "opacity-100 translate-y-0" : "opacity-0 -translate-y-full"
          }`}
          style={{
            backgroundColor: "rgba(255, 255, 255, 0.95)",
            backdropFilter: "blur(10px)",
            border: designSystem.colors.borders.accent,
            boxShadow: designSystem.shadows.brutalist,
            borderRadius: "12px",
          }}
        >
          <div className="max-w-7xl mx-auto px-3 sm:px-4 md:px-6 py-3 sm:py-4">
            <div className="flex justify-between items-center">
              {/* Logo */}
              <div className="flex items-center gap-2 sm:gap-3">
                <div
                  className="w-10 h-10 sm:w-12 sm:h-12 rounded-xl flex items-center justify-center"
                  style={{
                    background: `linear-gradient(135deg, ${designSystem.colors.primary} 0%, rgba(232, 244, 253, 0.8) 100%)`,
                    border: designSystem.colors.borders.light,
                  }}
                >
                  <Image
                    src="/icons/icon-512.png"
                    alt="ClgSphere Logo"
                    width={24}
                    height={24}
                    className="object-contain sm:hidden"
                  />
                  <Image
                    src="/icons/icon-512.png"
                    alt="ClgSphere Logo"
                    width={28}
                    height={28}
                    className="object-contain hidden sm:block"
                  />
                </div>
                <div className="flex flex-col sm:flex-row sm:items-center">
                  <span className="font-bold text-lg sm:text-xl" style={{ color: designSystem.colors.text.primary }}>
                    ClgSphere
                  </span>
                  <span className="text-xs text-gray-500 sm:ml-2 sm:pl-2 sm:border-l sm:border-gray-300 hidden sm:inline-block">
                    College Portal
                  </span>
                </div>
              </div>

              {/* Desktop Navigation */}
              <div className="hidden md:flex items-center space-x-1 lg:space-x-3">
                <div className="bg-white/50 backdrop-blur-sm px-2 py-1 rounded-lg border border-gray-100 flex items-center mr-2">
                  {["About", "Features", "Reviews"].map((item, index) => (
                    <button
                      key={item}
                      onClick={() => scrollToSection(item.toLowerCase())}
                      className="px-3 py-1.5 mx-1 font-medium text-sm rounded-lg transition-all duration-200 hover:scale-105"
                      style={{
                        background:
                          index === 0
                            ? `linear-gradient(135deg, ${designSystem.colors.primary} 0%, rgba(232, 244, 253, 0.6) 100%)`
                            : index === 1
                              ? `linear-gradient(135deg, ${designSystem.colors.secondary} 0%, rgba(240, 249, 255, 0.6) 100%)`
                              : `linear-gradient(135deg, ${designSystem.colors.accent} 0%, rgba(254, 247, 255, 0.6) 100%)`,
                        color: designSystem.colors.text.primary,
                        border: designSystem.colors.borders.light,
                        boxShadow: designSystem.shadows.soft,
                      }}
                    >
                      {item}
                    </button>
                  ))}
                </div>
                <Link href="/login">
                  <Button
                    className="px-4 sm:px-6 py-1.5 sm:py-2 font-semibold text-sm rounded-lg transition-all duration-200 hover:scale-105 flex items-center gap-1"
                    style={{
                      background: `linear-gradient(135deg, ${designSystem.colors.text.primary} 0%, rgba(30, 41, 59, 0.9) 100%)`,
                      color: designSystem.colors.text.light,
                      border: designSystem.colors.borders.medium,
                      boxShadow: designSystem.shadows.brutalist,
                    }}
                  >
                    <span className="hidden sm:inline">Login</span>
                    <span className="sm:hidden">Login</span>
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      width="16"
                      height="16"
                      viewBox="0 0 24 24"
                      fill="none"
                      stroke="currentColor"
                      strokeWidth="2"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      className="hidden sm:inline-block ml-1"
                    >
                      <path d="M15 3h4a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2h-4"></path>
                      <polyline points="10 17 15 12 10 7"></polyline>
                      <line x1="15" y1="12" x2="3" y2="12"></line>
                    </svg>
                  </Button>
                </Link>
              </div>

              {/* Mobile Menu Button */}
              <div className="md:hidden">
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={() => setIsMenuOpen(!isMenuOpen)}
                  className="rounded-lg p-1.5 sm:p-2 transition-all duration-300 ease-in-out hover:scale-110"
                  style={{
                    background: `linear-gradient(135deg, ${designSystem.colors.primary} 0%, rgba(232, 244, 253, 0.8) 100%)`,
                    border: designSystem.colors.borders.light,
                    transform: isMenuOpen ? "rotate(180deg)" : "rotate(0deg)",
                  }}
                >
                  <div className="relative w-5 h-5 flex items-center justify-center">
                    <Menu
                      className={`w-4 h-4 sm:w-5 sm:h-5 absolute transition-all duration-300 ease-in-out ${
                        isMenuOpen ? "opacity-0 scale-0 rotate-90" : "opacity-100 scale-100 rotate-0"
                      }`}
                      style={{ color: designSystem.colors.text.primary }}
                    />
                    <X
                      className={`w-4 h-4 sm:w-5 sm:h-5 absolute transition-all duration-300 ease-in-out ${
                        isMenuOpen ? "opacity-100 scale-100 rotate-0" : "opacity-0 scale-0 -rotate-90"
                      }`}
                      style={{ color: designSystem.colors.text.primary }}
                    />
                  </div>
                </Button>
              </div>
            </div>

            {/* Mobile Menu */}
            {isMenuOpen && (
              <div
                className="md:hidden mt-4 p-4 rounded-xl"
                style={{
                  background: `linear-gradient(135deg, ${designSystem.colors.backgrounds.section} 0%, rgba(248, 250, 252, 0.9) 100%)`,
                  border: designSystem.colors.borders.light,
                  boxShadow: designSystem.shadows.soft,
                }}
              >
                <div className="flex flex-col space-y-2">
                  {["About", "Features", "Reviews"].map((item, index) => (
                    <button
                      key={item}
                      onClick={() => {
                        scrollToSection(item.toLowerCase())
                        setIsMenuOpen(false)
                      }}
                      className="px-4 py-3 font-medium text-sm rounded-lg text-left hover:bg-white transition-colors"
                      style={{ color: designSystem.colors.text.secondary }}
                    >
                      {item}
                    </button>
                  ))}
                  <Link href="/login" className="block">
                    <Button
                      className="w-full px-4 py-3 font-semibold text-sm rounded-lg mt-2"
                      style={{
                        background: `linear-gradient(135deg, ${designSystem.colors.text.primary} 0%, rgba(30, 41, 59, 0.9) 100%)`,
                        color: designSystem.colors.text.light,
                        border: "none",
                      }}
                    >
                      Login
                    </Button>
                  </Link>
                </div>
              </div>
            )}
          </div>
        </nav>

        {/* Hero Section with Soft Pastel Colors */}
        <section className="pt-16 sm:pt-28 pb-4 sm:pb-16 min-h-screen flex items-center justify-center relative overflow-hidden">
          {/* Soft Pastel Background Gradients */}
          <div className="absolute inset-0">
            <div
              className="absolute inset-0"
              style={{
                background: `
                  radial-gradient(circle at 25% 25%, rgba(227, 242, 253, 0.4) 0%, transparent 50%),
                  radial-gradient(circle at 75% 25%, rgba(243, 229, 245, 0.3) 0%, transparent 50%),
                  radial-gradient(circle at 25% 75%, rgba(232, 245, 232, 0.3) 0%, transparent 50%),
                  radial-gradient(circle at 75% 75%, rgba(255, 249, 196, 0.2) 0%, transparent 50%),
                  linear-gradient(135deg, rgba(227, 242, 253, 0.1) 0%, rgba(243, 229, 245, 0.1) 50%, rgba(252, 228, 236, 0.1) 100%)
                `,
              }}
            />
          </div>

          {/* Enhanced Floating Background Elements */}
          <div className="absolute inset-0 pointer-events-none">
            {/* Large floating shapes */}
            <div
              className="absolute top-20 left-10 w-32 h-32 rounded-3xl rotate-12 opacity-30 animate-pulse"
              style={{
                background: `linear-gradient(135deg, #E3F2FD 0%, #BBDEFB 100%)`,
                filter: "blur(2px)",
                animation: "float 6s ease-in-out infinite",
              }}
            ></div>
            <div
              className="absolute top-40 right-20 w-24 h-24 rounded-2xl -rotate-12 opacity-25 animate-pulse"
              style={{
                background: `linear-gradient(135deg, #F3E5F5 0%, #E1BEE7 100%)`,
                filter: "blur(1px)",
                animation: "float 8s ease-in-out infinite reverse",
              }}
            ></div>
            <div
              className="absolute bottom-40 left-20 w-20 h-20 rounded-xl rotate-45 opacity-35 animate-pulse"
              style={{
                background: `linear-gradient(135deg, #E8F5E8 0%, #C8E6C9 100%)`,
                filter: "blur(1px)",
                animation: "float 7s ease-in-out infinite",
              }}
            ></div>
            <div
              className="absolute top-60 right-40 w-16 h-16 rounded-full opacity-30 animate-pulse"
              style={{
                background: `linear-gradient(135deg, #FCE4EC 0%, #F8BBD9 100%)`,
                animation: "float 5s ease-in-out infinite reverse",
              }}
            ></div>
            <div
              className="absolute bottom-60 right-10 w-28 h-28 rounded-2xl rotate-30 opacity-25 animate-pulse"
              style={{
                background: `linear-gradient(135deg, #FFF9C4 0%, #FFF59D 100%)`,
                filter: "blur(2px)",
                animation: "float 9s ease-in-out infinite",
              }}
            ></div>

            {/* Small decorative dots */}
            <div
              className="absolute top-32 left-1/3 w-4 h-4 rounded-full opacity-40"
              style={{ background: "#BBDEFB", animation: "float 4s ease-in-out infinite" }}
            ></div>
            <div
              className="absolute bottom-32 right-1/3 w-6 h-6 rounded-full opacity-35"
              style={{ background: "#E1BEE7", animation: "float 6s ease-in-out infinite reverse" }}
            ></div>
            <div
              className="absolute top-1/2 left-10 w-3 h-3 rounded-full opacity-45"
              style={{ background: "#C8E6C9", animation: "float 5s ease-in-out infinite" }}
            ></div>
          </div>

          <BlurryBlob
            firstBlobColor="bg-blue-100/20"
            secondBlobColor="bg-purple-100/15"
            className="absolute inset-0 z-10 pointer-events-none"
          />

          <div className="max-w-7xl mx-auto px-6 text-center relative z-20 -mt-6 sm:mt-0">
            <div
              className={`transition-all duration-1000 ${isVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-10"}`}
            >
              {/* Logo with Soft Gradient */}
              <div
                className="w-20 h-20 sm:w-32 sm:h-32 rounded-3xl flex items-center justify-center mx-auto mb-4 sm:mb-8 relative"
                style={{
                  background: `linear-gradient(135deg, rgba(255, 255, 255, 0.95) 0%, rgba(227, 242, 253, 0.8) 50%, rgba(243, 229, 245, 0.6) 100%)`,
                  border: "2px solid rgba(227, 242, 253, 0.6)",
                  boxShadow: "0 8px 32px rgba(227, 242, 253, 0.3), 4px 4px 0px rgba(30, 41, 59, 0.1)",
                  backdropFilter: "blur(15px)",
                }}
              >
                <Image
                  src="/icons/icon-512.png"
                  alt="ClgSphere Logo"
                  width={58}
                  height={58}
                  className="object-contain relative z-10 sm:hidden"
                />
                <Image
                  src="/icons/icon-512.png"
                  alt="ClgSphere Logo"
                  width={64}
                  height={64}
                  className="object-contain relative z-10 hidden sm:block"
                />
                {/* Glow effect */}
                <div
                  className="absolute inset-0 rounded-3xl opacity-50"
                  style={{
                    background: `radial-gradient(circle, rgba(227, 242, 253, 0.4) 0%, transparent 70%)`,
                    filter: "blur(8px)",
                  }}
                />
              </div>

              {/* Main Heading with Enhanced Styling */}
              <div className="mb-3 sm:mb-6">
                <h1
                  className="text-3xl sm:text-4xl md:text-6xl lg:text-7xl font-bold mb-3 sm:mb-6 leading-tight"
                  style={{ color: designSystem.colors.text.primary }}
                >
                  <SplitText
                    text="Saraswati College "
                    className="text-4xl md:text-6xl lg:text-7xl font-bold inline-block"
                    delay={50}
                    duration={2}
                    ease="elastic.out(1,0.3)"
                    splitType="chars"
                    from={{ opacity: 0, y: 20, scale: 0.87 }}
                    to={{ opacity: 1, y: 0, scale: 1 }}
                    threshold={0.1}
                    rootMargin="-100px"
                    textAlign="center"
                  />
                </h1>
                <div
                  className="px-4 py-2 sm:px-6 sm:py-3 rounded-2xl mb-4 sm:mb-6 relative"
                  style={{
                    background: `linear-gradient(135deg, rgba(248, 250, 252, 0.8) 0%, rgba(232, 244, 253, 0.4) 50%, rgba(243, 229, 245, 0.3) 100%)`,
                    border: "1px solid rgba(227, 242, 253, 0.3)",
                    boxShadow: "0 2px 8px rgba(227, 242, 253, 0.1)",
                    backdropFilter: "blur(5px)",
                  }}
                >
                  <span
                    className="text-lg sm:text-xl md:text-2xl lg:text-3xl font-bold relative z-10"
                    style={{ color: designSystem.colors.text.primary }}
                  >
                    Management System
                  </span>
                  {/* Subtle inner glow */}
                  <div
                    className="absolute inset-0 rounded-2xl opacity-30"
                    style={{
                      background: `radial-gradient(ellipse at center, rgba(227, 242, 253, 0.3) 0%, transparent 70%)`,
                    }}
                  />
                </div>
              </div>

              {/* Subtitle with Gradient Background */}
              <div
                className="px-4 py-2 sm:px-6 sm:py-3 rounded-full mb-6 sm:mb-8 relative"
                style={{
                  background: `linear-gradient(135deg, rgba(232, 245, 232, 0.7) 0%, rgba(255, 249, 196, 0.5) 50%, rgba(255, 243, 224, 0.6) 100%)`,
                  border: "1px solid rgba(232, 245, 232, 0.6)",
                  boxShadow: "0 4px 16px rgba(232, 245, 232, 0.2)",
                  backdropFilter: "blur(8px)",
                }}
              >
                <p
                  className="text-base sm:text-lg font-medium relative z-10"
                  style={{ color: designSystem.colors.text.primary }}
                >
                  Your campus in your pocket ✨
                </p>
              </div>

              {/* Action Buttons with Gradient Backgrounds */}
              <div className="flex flex-col sm:flex-row gap-3 sm:gap-6 justify-center mb-6 sm:mb-12 md:mb-16">
                <Link href="/login">
                  <Button
                    className="px-6 py-3 sm:px-8 sm:py-4 font-semibold text-base rounded-2xl transition-all duration-300 hover:scale-105 hover:shadow-lg relative overflow-hidden"
                    style={{
                      background: `linear-gradient(135deg, #3B82F6 0%, #1D4ED8 100%)`,
                      color: designSystem.colors.text.light,
                      border: "2px solid rgba(59, 130, 246, 0.3)",
                      boxShadow: "0 8px 25px rgba(59, 130, 246, 0.4), 4px 4px 0px rgba(29, 78, 216, 0.2)",
                    }}
                  >
                    Login to Dashboard
                  </Button>
                </Link>
                <Button
                  onClick={() => scrollToSection("app-preview")}
                  className="px-6 py-3 sm:px-8 sm:py-4 font-semibold text-base rounded-2xl transition-all duration-300 hover:scale-105 hover:shadow-lg relative overflow-hidden"
                  style={{
                    background: `linear-gradient(135deg, rgba(227, 242, 253, 0.9) 0%, rgba(243, 229, 245, 0.7) 50%, rgba(232, 245, 232, 0.6) 100%)`,
                    color: designSystem.colors.text.primary,
                    border: "2px solid rgba(227, 242, 253, 0.6)",
                    boxShadow: "0 4px 16px rgba(227, 242, 253, 0.3)",
                    backdropFilter: "blur(10px)",
                  }}
                >
                  Explore App 🚀
                </Button>
              </div>

              {/* Enhanced Stats with Colorful Cards */}
              <div className="grid grid-cols-2 md:grid-cols-4 gap-3 sm:gap-5 md:gap-8 max-w-5xl mx-auto mb-4 sm:mb-8">
                {[
                  {
                    value: 1500,
                    label: "Students",
                    suffix: "+",
                    gradient: "linear-gradient(135deg, #E3F2FD 0%, #BBDEFB 100%)",
                    shadow: "rgba(187, 222, 251, 0.3)",
                  },
                  {
                    value: 300,
                    label: "Faculty",
                    suffix: "+",
                    gradient: "linear-gradient(135deg, #F3E5F5 0%, #E1BEE7 100%)",
                    shadow: "rgba(225, 190, 231, 0.3)",
                  },
                  {
                    value: 25,
                    label: "Years",
                    suffix: "+",
                    gradient: "linear-gradient(135deg, #E8F5E8 0%, #C8E6C9 100%)",
                    shadow: "rgba(200, 230, 201, 0.3)",
                  },
                  {
                    value: 95,
                    label: "Placement",
                    suffix: "%",
                    gradient: "linear-gradient(135deg, #FFF9C4 0%, #FFF59D 100%)",
                    shadow: "rgba(255, 245, 157, 0.3)",
                  },
                ].map((stat, index) => (
                  <div
                    key={index}
                    className="p-3 sm:p-4 md:p-6 rounded-2xl text-center transition-all duration-300 hover:scale-105 hover:shadow-xl relative overflow-hidden"
                    style={{
                      background: stat.gradient,
                      border: "1px solid rgba(255, 255, 255, 0.3)",
                      boxShadow: `0 6px 24px ${stat.shadow}, ${index % 2 === 0 ? "4px 4px 0px rgba(30, 41, 59, 0.08)" : "0 4px 16px rgba(0, 0, 0, 0.1)"}`,
                      backdropFilter: "blur(10px)",
                    }}
                  >
                    {/* Subtle inner glow */}
                    <div
                      className="absolute inset-0 rounded-2xl opacity-40"
                      style={{
                        background: `radial-gradient(circle at 50% 20%, rgba(255, 255, 255, 0.3) 0%, transparent 60%)`,
                      }}
                    />
                    <div
                      className="text-2xl sm:text-3xl md:text-4xl font-bold mb-2 relative z-10"
                      style={{ color: designSystem.colors.text.primary }}
                    >
                      <CountUp from={0} to={stat.value} separator="," direction="up" duration={1.5} />
                      {stat.suffix}
                    </div>
                    <div
                      className="text-sm font-medium relative z-10"
                      style={{ color: designSystem.colors.text.secondary }}
                    >
                      {stat.label}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </section>

        {/* About Section */}
        <section
          id="about"
          className="py-16 relative"
          style={{
            background: `linear-gradient(135deg, rgba(248, 250, 252, 0.8) 0%, rgba(232, 244, 253, 0.3) 100%)`,
          }}
        >
          <div className="max-w-7xl mx-auto px-6">
            <div className="text-center mb-12">
              <div
                className="inline-block px-6 py-3 rounded-xl mb-6"
                style={{
                  background: `linear-gradient(135deg, ${designSystem.colors.primary} 0%, rgba(232, 244, 253, 0.8) 100%)`,
                  border: designSystem.colors.borders.accent,
                  boxShadow: designSystem.shadows.brutalist,
                  backdropFilter: "blur(10px)",
                }}
              >
                <h2 className="text-3xl md:text-4xl font-bold" style={{ color: designSystem.colors.text.primary }}>
                  About Our College
                </h2>
              </div>
              <p className="text-lg max-w-3xl mx-auto" style={{ color: designSystem.colors.text.secondary }}>
                Established in 2004, Saraswati College of Engineering has been at the forefront of technical education
              </p>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
              {/* Left Content */}
              <div className="space-y-6">
                {[
                  {
                    icon: Award,
                    title: "20+ Years of Excellence",
                    description: "Pioneering education since 2004",
                    color: designSystem.colors.primary,
                  },
                  {
                    icon: Building,
                    title: "World-Class Faculty",
                    description: "300+ expert educators and professionals",
                    color: designSystem.colors.secondary,
                  },
                  {
                    icon: Target,
                    title: "95% Placement Success",
                    description: "Strong industry partnerships",
                    color: designSystem.colors.accent,
                  },
                ].map((item, index) => (
                  <div
                    key={index}
                    className="p-6 rounded-xl transition-all duration-200 hover:scale-105"
                    style={{
                      background: `linear-gradient(135deg, ${item.color} 0%, rgba(${
                        item.color === designSystem.colors.primary
                          ? "232, 244, 253"
                          : item.color === designSystem.colors.secondary
                            ? "240, 249, 255"
                            : "254, 247, 255"
                      }, 0.6) 100%)`,
                      border: designSystem.colors.borders.light,
                      boxShadow: index === 1 ? designSystem.shadows.brutalist : designSystem.shadows.soft,
                      backdropFilter: "blur(5px)",
                    }}
                  >
                    <div className="flex items-center gap-4">
                      <div
                        className="w-12 h-12 rounded-lg flex items-center justify-center flex-shrink-0"
                        style={{
                          background: `linear-gradient(135deg, rgba(255, 255, 255, 0.9) 0%, rgba(255, 255, 255, 0.7) 100%)`,
                          border: designSystem.colors.borders.light,
                          backdropFilter: "blur(5px)",
                        }}
                      >
                        <item.icon className="w-6 h-6" style={{ color: designSystem.colors.text.primary }} />
                      </div>
                      <div>
                        <h3 className="text-lg font-semibold mb-1" style={{ color: designSystem.colors.text.primary }}>
                          {item.title}
                        </h3>
                        <p className="text-sm" style={{ color: designSystem.colors.text.secondary }}>
                          {item.description}
                        </p>
                      </div>
                    </div>
                  </div>
                ))}
              </div>

              {/* Right Content - Principal's Quote */}
              <div
                className="p-8 rounded-xl"
                style={{
                  background: `linear-gradient(135deg, rgba(255, 255, 255, 0.9) 0%, rgba(232, 244, 253, 0.6) 100%)`,
                  border: designSystem.colors.borders.accent,
                  boxShadow: designSystem.shadows.brutalist,
                  backdropFilter: "blur(10px)",
                }}
              >
                <Quote className="w-8 h-8 mb-4" style={{ color: designSystem.colors.text.muted }} />
                <p className="text-lg mb-6 italic" style={{ color: designSystem.colors.text.primary }}>
                  "Education is the most powerful weapon which you can use to change the world. At Saraswati College,
                  we're not just teaching - we're transforming futures."
                </p>
                <div className="flex items-center gap-3">
                  <div
                    className="w-12 h-12 rounded-full flex items-center justify-center"
                    style={{
                      background: `linear-gradient(135deg, ${designSystem.colors.primary} 0%, rgba(232, 244, 253, 0.8) 100%)`,
                      backdropFilter: "blur(5px)",
                    }}
                  >
                    <span className="font-semibold text-sm" style={{ color: designSystem.colors.text.primary }}>
                      MD
                    </span>
                  </div>
                  <div>
                    <div className="font-semibold text-sm" style={{ color: designSystem.colors.text.primary }}>
                      Dr. Manjusha Deshmukh
                    </div>
                    <div className="text-xs" style={{ color: designSystem.colors.text.secondary }}>
                      Principal & Director
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Features Section */}
        <section id="features" className="py-16">
          <div className="max-w-7xl mx-auto px-6">
            <div className="text-center mb-12">
              <div
                className="inline-block px-6 py-3 rounded-xl mb-6"
                style={{
                  background: `linear-gradient(135deg, ${designSystem.colors.secondary} 0%, rgba(240, 249, 255, 0.8) 100%)`,
                  border: designSystem.colors.borders.light,
                  boxShadow: designSystem.shadows.brutalist,
                  backdropFilter: "blur(10px)",
                }}
              >
                <h2 className="text-3xl md:text-4xl font-bold" style={{ color: designSystem.colors.text.primary }}>
                  Student Benefits
                </h2>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {features.map((feature, index) => (
                <div
                  key={index}
                  className="p-6 rounded-xl transition-all duration-200 hover:scale-105"
                  style={{
                    background: `linear-gradient(135deg, ${
                      index === 0
                        ? "rgba(227, 242, 253, 0.6)"
                        : index === 1
                          ? "rgba(243, 229, 245, 0.5)"
                          : index === 2
                            ? "rgba(232, 245, 232, 0.5)"
                            : "rgba(255, 249, 196, 0.4)"
                    } 0%, rgba(255, 255, 255, 0.8) 100%)`,
                    border: designSystem.colors.borders.light,
                    boxShadow: index % 2 === 0 ? designSystem.shadows.brutalist : designSystem.shadows.soft,
                    backdropFilter: "blur(10px)",
                  }}
                >
                  <div className="flex items-start gap-4">
                    <div
                      className="w-12 h-12 rounded-lg flex items-center justify-center flex-shrink-0"
                      style={{
                        background: `linear-gradient(135deg, ${
                          [
                            designSystem.colors.primary,
                            designSystem.colors.secondary,
                            designSystem.colors.accent,
                            designSystem.colors.subtle,
                          ][index]
                        } 0%, rgba(${
                          index === 0
                            ? "232, 244, 253"
                            : index === 1
                              ? "240, 249, 255"
                              : index === 2
                                ? "254, 247, 255"
                                : "248, 250, 252"
                        }, 0.6) 100%)`,
                        border: designSystem.colors.borders.light,
                        backdropFilter: "blur(5px)",
                      }}
                    >
                      <feature.icon className="w-6 h-6" style={{ color: designSystem.colors.text.primary }} />
                    </div>
                    <div>
                      <h3 className="text-lg font-semibold mb-2" style={{ color: designSystem.colors.text.primary }}>
                        {feature.title}
                      </h3>
                      <p className="text-sm" style={{ color: designSystem.colors.text.secondary }}>
                        {feature.description}
                      </p>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* App Preview Section */}
        <section
          id="app-preview"
          className="py-16"
          style={{
            background: `linear-gradient(135deg, rgba(252, 228, 236, 0.3) 0%, rgba(255, 243, 224, 0.2) 50%, rgba(248, 250, 252, 0.8) 100%)`,
          }}
        >
          <div className="max-w-7xl mx-auto px-6">
            <div className="text-center mb-12">
              <div
                className="inline-block px-6 py-3 rounded-xl mb-6"
                style={{
                  background: `linear-gradient(135deg, ${designSystem.colors.accent} 0%, rgba(254, 247, 255, 0.8) 100%)`,
                  border: designSystem.colors.borders.light,
                  boxShadow: designSystem.shadows.brutalist,
                  backdropFilter: "blur(10px)",
                }}
              >
                <h2 className="text-3xl md:text-4xl font-bold" style={{ color: designSystem.colors.text.primary }}>
                  App Preview
                </h2>
              </div>
            </div>

            <div className="max-w-4xl mx-auto">
              <div
                className="p-8 rounded-xl"
                style={{
                  background: `linear-gradient(135deg, rgba(255, 255, 255, 0.9) 0%, rgba(232, 244, 253, 0.4) 100%)`,
                  border: designSystem.colors.borders.accent,
                  boxShadow: designSystem.shadows.brutalist,
                  backdropFilter: "blur(15px)",
                }}
              >
                <div className="text-center mb-6">
                  <div
                    className="w-full h-64 rounded-xl flex items-center justify-center mb-6 relative overflow-hidden"
                    style={{
                      background: `linear-gradient(135deg, ${designSystem.colors.primary} 0%, rgba(232, 244, 253, 0.7) 100%)`,
                      border: designSystem.colors.borders.light,
                      backdropFilter: "blur(5px)",
                    }}
                  >
                    <div className="text-center">
                      <div
                        className="w-16 h-16 rounded-xl flex items-center justify-center mx-auto mb-4"
                        style={{
                          background: `linear-gradient(135deg, rgba(255, 255, 255, 0.9) 0%, rgba(255, 255, 255, 0.7) 100%)`,
                          backdropFilter: "blur(5px)",
                        }}
                      >
                        <Image
                          src="/icons/icon-192.png"
                          alt="ClgSphere Logo"
                          width={32}
                          height={32}
                          className="object-contain"
                        />
                      </div>
                      <h3 className="text-xl font-semibold mb-2" style={{ color: designSystem.colors.text.primary }}>
                        {appScreenshots[currentSlide].title}
                      </h3>
                      <p className="text-sm" style={{ color: designSystem.colors.text.secondary }}>
                        {appScreenshots[currentSlide].description}
                      </p>
                    </div>
                  </div>

                  {/* Navigation Buttons */}
                  <div className="flex justify-center gap-4 mb-6">
                    <Button
                      onClick={prevSlide}
                      variant="outline"
                      size="icon"
                      className="rounded-lg bg-transparent"
                      style={{
                        background: `linear-gradient(135deg, ${designSystem.colors.secondary} 0%, rgba(240, 249, 255, 0.8) 100%)`,
                        border: designSystem.colors.borders.light,
                        boxShadow: designSystem.shadows.soft,
                        backdropFilter: "blur(5px)",
                      }}
                    >
                      <ChevronLeft className="w-4 h-4" />
                    </Button>
                    <Button
                      onClick={nextSlide}
                      variant="outline"
                      size="icon"
                      className="rounded-lg bg-transparent"
                      style={{
                        background: `linear-gradient(135deg, ${designSystem.colors.secondary} 0%, rgba(240, 249, 255, 0.8) 100%)`,
                        border: designSystem.colors.borders.light,
                        boxShadow: designSystem.shadows.soft,
                        backdropFilter: "blur(5px)",
                      }}
                    >
                      <ChevronRight className="w-4 h-4" />
                    </Button>
                  </div>

                  {/* Dots Indicator */}
                  <div className="flex justify-center gap-2">
                    {appScreenshots.map((_, index) => (
                      <button
                        key={index}
                        onClick={() => setCurrentSlide(index)}
                        className="w-2 h-2 rounded-full transition-all duration-200"
                        style={{
                          backgroundColor:
                            index === currentSlide ? designSystem.colors.text.primary : designSystem.colors.text.muted,
                        }}
                      />
                    ))}
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Testimonials Section */}
        <section id="testimonials" className="py-16">
          <div className="max-w-7xl mx-auto px-6">
            <div className="text-center mb-12">
              <div
                className="inline-block px-6 py-3 rounded-xl mb-6"
                style={{
                  background: `linear-gradient(135deg, ${designSystem.colors.primary} 0%, rgba(232, 244, 253, 0.8) 100%)`,
                  border: designSystem.colors.borders.accent,
                  boxShadow: designSystem.shadows.brutalist,
                  backdropFilter: "blur(10px)",
                }}
              >
                <h2 className="text-3xl md:text-4xl font-bold" style={{ color: designSystem.colors.text.primary }}>
                  Success Stories
                </h2>
              </div>
            </div>

            <div className="max-w-3xl mx-auto">
              <div
                className="p-8 rounded-xl text-center"
                style={{
                  background: `linear-gradient(135deg, rgba(255, 255, 255, 0.9) 0%, rgba(248, 250, 252, 0.8) 100%)`,
                  border: designSystem.colors.borders.light,
                  boxShadow: designSystem.shadows.brutalist,
                  backdropFilter: "blur(15px)",
                }}
              >
                <div className="flex justify-center mb-4">
                  {[...Array(5)].map((_, i) => (
                    <Star key={i} className="w-5 h-5 text-yellow-400 fill-current" />
                  ))}
                </div>
                <p className="text-lg mb-6" style={{ color: designSystem.colors.text.primary }}>
                  "{testimonials[currentSlide].quote}"
                </p>

                <div className="flex items-center justify-center gap-3">
                  <div
                    className="w-12 h-12 rounded-full flex items-center justify-center"
                    style={{
                      background: `linear-gradient(135deg, ${designSystem.colors.primary} 0%, rgba(232, 244, 253, 0.8) 100%)`,
                      backdropFilter: "blur(5px)",
                    }}
                  >
                    <span className="text-sm font-semibold" style={{ color: designSystem.colors.text.primary }}>
                      {testimonials[currentSlide].name.charAt(0)}
                    </span>
                  </div>
                  <div className="text-left">
                    <div className="flex items-center gap-2">
                      <span className="font-semibold text-sm" style={{ color: designSystem.colors.text.primary }}>
                        {testimonials[currentSlide].name}
                      </span>
                      <CheckCircle className="w-4 h-4 text-green-500" />
                    </div>
                    <p className="text-xs" style={{ color: designSystem.colors.text.secondary }}>
                      {testimonials[currentSlide].role}
                    </p>
                  </div>
                </div>

                <div className="flex justify-center gap-2 mt-6">
                  {testimonials.map((_, index) => (
                    <button
                      key={index}
                      onClick={() => setCurrentSlide(index)}
                      className="w-2 h-2 rounded-full transition-all duration-200"
                      style={{
                        backgroundColor:
                          index === currentSlide ? designSystem.colors.text.primary : designSystem.colors.text.muted,
                      }}
                    />
                  ))}
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* CTA Section */}
        <section className="py-16" style={{ backgroundColor: designSystem.colors.backgrounds.dark }}>
          <div className="max-w-7xl mx-auto px-6 text-center">
            <div
              className="inline-block px-6 py-3 rounded-xl mb-6"
              style={{
                background: `linear-gradient(135deg, ${designSystem.colors.primary} 0%, rgba(232, 244, 253, 0.9) 100%)`,
                border: designSystem.colors.borders.light,
                boxShadow: designSystem.shadows.brutalist,
                backdropFilter: "blur(10px)",
              }}
            >
              <h2 className="text-3xl md:text-4xl font-bold" style={{ color: designSystem.colors.text.primary }}>
                Ready to Transform?
              </h2>
            </div>
            <p className="text-lg mb-8 max-w-2xl mx-auto" style={{ color: designSystem.colors.text.light }}>
              Join thousands of students already using ClgSphere
            </p>

            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button
                className="px-8 py-3 font-semibold text-base rounded-xl transition-all duration-200 hover:scale-105"
                style={{
                  background: `linear-gradient(135deg, ${designSystem.colors.text.light} 0%, rgba(255, 255, 255, 0.9) 100%)`,
                  color: designSystem.colors.text.primary,
                  border: designSystem.colors.borders.medium,
                  boxShadow: designSystem.shadows.brutalist,
                }}
              >
                Get Started Today
              </Button>
              <Button
                className="px-8 py-3 font-semibold text-base rounded-xl transition-all duration-200 hover:scale-105"
                style={{
                  background: `linear-gradient(135deg, ${designSystem.colors.primary} 0%, rgba(232, 244, 253, 0.9) 100%)`,
                  color: designSystem.colors.text.primary,
                  border: designSystem.colors.borders.light,
                  boxShadow: designSystem.shadows.soft,
                  backdropFilter: "blur(5px)",
                }}
              >
                Contact Support
              </Button>
            </div>
          </div>
        </section>

        {/* Contact Section */}
        <section
          className="py-16"
          style={{
            background: `linear-gradient(135deg, rgba(248, 250, 252, 0.8) 0%, rgba(240, 249, 255, 0.3) 100%)`,
          }}
        >
          <div className="max-w-7xl mx-auto px-6">
            <div className="text-center mb-12">
              <div
                className="inline-block px-6 py-3 rounded-xl mb-6"
                style={{
                  background: `linear-gradient(135deg, ${designSystem.colors.secondary} 0%, rgba(240, 249, 255, 0.8) 100%)`,
                  border: designSystem.colors.borders.light,
                  boxShadow: designSystem.shadows.brutalist,
                  backdropFilter: "blur(10px)",
                }}
              >
                <h2 className="text-3xl md:text-4xl font-bold" style={{ color: designSystem.colors.text.primary }}>
                  Get in Touch
                </h2>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {[
                {
                  icon: MapPin,
                  title: "Visit Us",
                  content: ["Saraswati College of Engineering", "Kharghar, Navi Mumbai", "Maharashtra 410210"],
                  color: designSystem.colors.primary,
                },
                {
                  icon: Phone,
                  title: "Call Us",
                  content: ["+91 98765 43210", "+91 87654 32109", "Mon-Fri: 9 AM - 6 PM"],
                  color: designSystem.colors.secondary,
                },
                {
                  icon: Mail,
                  title: "Email Us",
                  content: ["info@saraswatice.edu.in", "support@saraswatice.edu.in", "Quick response guaranteed"],
                  color: designSystem.colors.accent,
                },
              ].map((contact, index) => (
                <div
                  key={index}
                  className="p-6 rounded-xl text-center transition-all duration-200 hover:scale-105"
                  style={{
                    background: `linear-gradient(135deg, ${contact.color} 0%, rgba(${
                      contact.color === designSystem.colors.primary
                        ? "232, 244, 253"
                        : contact.color === designSystem.colors.secondary
                          ? "240, 249, 255"
                          : "254, 247, 255"
                    }, 0.6) 100%)`,
                    border: designSystem.colors.borders.light,
                    boxShadow: index === 1 ? designSystem.shadows.brutalist : designSystem.shadows.soft,
                    backdropFilter: "blur(10px)",
                  }}
                >
                  <div
                    className="w-12 h-12 rounded-lg flex items-center justify-center mx-auto mb-4"
                    style={{
                      background: `linear-gradient(135deg, rgba(255, 255, 255, 0.9) 0%, rgba(255, 255, 255, 0.7) 100%)`,
                      border: designSystem.colors.borders.light,
                      backdropFilter: "blur(5px)",
                    }}
                  >
                    <contact.icon className="w-6 h-6" style={{ color: designSystem.colors.text.primary }} />
                  </div>
                  <h3 className="text-lg font-semibold mb-4" style={{ color: designSystem.colors.text.primary }}>
                    {contact.title}
                  </h3>
                  {contact.content.map((line, lineIndex) => (
                    <p key={lineIndex} className="text-sm mb-1" style={{ color: designSystem.colors.text.secondary }}>
                      {line}
                    </p>
                  ))}
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* Footer */}
        <footer className="py-12" style={{ backgroundColor: designSystem.colors.backgrounds.dark }}>
          <div className="max-w-7xl mx-auto px-6">
            <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
              {/* Logo and Description */}
              <div className="md:col-span-2">
                <div className="flex items-center gap-3 mb-4">
                  <div
                    className="w-10 h-10 rounded-lg flex items-center justify-center"
                    style={{
                      background: `linear-gradient(135deg, ${designSystem.colors.primary} 0%, rgba(232, 244, 253, 0.8) 100%)`,
                      backdropFilter: "blur(5px)",
                    }}
                  >
                    <Image
                      src="/icons/icon-512.png"
                      alt="ClgSphere Logo"
                      width={24}
                      height={24}
                      className="object-contain"
                    />
                  </div>
                  <span className="font-bold text-xl" style={{ color: designSystem.colors.text.light }}>
                    ClgSphere
                  </span>
                </div>
                <p className="text-sm mb-6 max-w-md" style={{ color: designSystem.colors.text.light }}>
                  Empowering students at Saraswati College of Engineering with digital tools for academic excellence.
                </p>
                <div className="flex gap-3">
                  {[Facebook, Instagram, Linkedin, Globe].map((Icon, index) => (
                    <a
                      key={index}
                      href="#"
                      className="w-8 h-8 rounded-lg flex items-center justify-center transition-colors hover:bg-gray-700"
                      style={{
                        background: `linear-gradient(135deg, ${
                          [
                            designSystem.colors.primary,
                            designSystem.colors.secondary,
                            designSystem.colors.accent,
                            designSystem.colors.subtle,
                          ][index]
                        } 0%, rgba(${
                          index === 0
                            ? "232, 244, 253"
                            : index === 1
                              ? "240, 249, 255"
                              : index === 2
                                ? "254, 247, 255"
                                : "248, 250, 252"
                        }, 0.8) 100%)`,
                        backdropFilter: "blur(5px)",
                      }}
                    >
                      <Icon className="w-4 h-4" style={{ color: designSystem.colors.text.primary }} />
                    </a>
                  ))}
                </div>
              </div>

              {/* Quick Links */}
              <div>
                <h4 className="font-semibold text-sm mb-4" style={{ color: designSystem.colors.text.light }}>
                  Quick Links
                </h4>
                <ul className="space-y-2">
                  {["About College", "Admissions", "Academic Calendar", "Placements"].map((link, index) => (
                    <li key={index}>
                      <a href="#" className="text-sm hover:underline" style={{ color: designSystem.colors.text.light }}>
                        {link}
                      </a>
                    </li>
                  ))}
                </ul>
              </div>

              {/* Support */}
              <div>
                <h4 className="font-semibold text-sm mb-4" style={{ color: designSystem.colors.text.light }}>
                  Support
                </h4>
                <ul className="space-y-2">
                  {["Help Center", "Contact Us", "Privacy Policy", "Terms of Service"].map((link, index) => (
                    <li key={index}>
                      <a href="#" className="text-sm hover:underline" style={{ color: designSystem.colors.text.light }}>
                        {link}
                      </a>
                    </li>
                  ))}
                </ul>
              </div>
            </div>

            <div className="border-t border-gray-600 mt-8 pt-8 text-center">
              <p className="text-sm" style={{ color: designSystem.colors.text.light }}>
                © 2025 Saraswati College of Engineering. All rights reserved.
              </p>
            </div>
          </div>
        </footer>
      </div>
    </div>
  )
}
